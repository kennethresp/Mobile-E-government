<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>


<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>The Official Website of Lagos State</title>
	<script src="indexs_files/jquery-1.js" type="text/javascript"></script>
	<script src="indexs_files/menu.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="indexs_files/stylesheet.css">
 <link rel="shortcut icon" href="http://www.lagosstate.gov.ng/favicon.ico">
 <link rel="icon" type="image/gif" href="http://www.lagosstate.gov.ng/animated_favicon1.gif">

<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"><title>The Official Website of Lagos State</title><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1"><title>Untitled Document</title></head><body>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
    <tbody><tr>
    <td align="center" bgcolor="#00cc00" height="102"><img src="indexs_files/header1.jpg" width="900" height="102"></td>
  </tr>
  <tr>
    <td align="center" background="indexs_files/headerbase.jpg"><img src="indexs_files/headerbase.jpg" width="6" height="5"></td>
  </tr>
      <tr>
    <td height="3"></td>
  </tr>
</tbody></table>	    
<link rel="stylesheet" type="text/css" href="indexs_files/stylesheet.css"><table align="center" border="0" cellpadding="0" cellspacing="0" width="900">
  
<tbody><tr>
    <td align="center">	<div id="container"><embed type="application/x-shockwave-flash" src="indexs_files/imagerotator.swf" style="" id="rotator" name="rotator" quality="high" allowfullscreen="true" flashvars="file=madrid.xml&amp;width=900&amp;height=140" width="900" height="140"></div>
	<script type="text/javascript" src="indexs_files/swfobject.js"></script>
	<script type="text/javascript">
		var s1 = new SWFObject("imagerotator.swf","rotator","900","140","7");
		s1.addParam("allowfullscreen","true");
		s1.addVariable("file","madrid.xml");
		s1.addVariable("width","900");
		s1.addVariable("height","140");
		s1.write("container");
	</script></td>
  </tr>
  </tbody></table>
<table align="center" border="0" cellpadding="0" cellspacing="0" width="900">
  
<tbody><tr>
    <td bgcolor="#ffffff"><table width="900">
      <tbody><tr>
        <td valign="top" width="240"><link rel="stylesheet" type="text/css" href="indexs_files/stylesheet.css">
<style type="text/css">
<!--
.style1 {font-size: 16px}
-->
</style>
<table cellpadding="0" cellspacing="0" width="100%">
  <tbody><tr>
    <td align="center"><table border="0" cellpadding="0" cellspacing="0" width="47%">
      <tbody><tr>
        <td><img src="indexs_files/thumb-top-left.gif" width="24" height="24"></td>
        <td><img src="indexs_files/thumb-top.gif" width="160" height="24"></td>
        <td><img src="indexs_files/thumb-top-right.gif" width="26" height="24"></td>
      </tr>
      <tr>
        <td><a href="http://www.tundefashola.com/"><img src="indexs_files/thumb-left.gif" width="24" height="159"></a></td>
        <td><a href="http://www.tundefashola.com/"><img src="indexs_files/image_gallery_002.jpg" border="0" width="160" height="159"></a></td>
        <td><img src="indexs_files/thumb-right.gif" width="26" height="159"></td>
      </tr>
      <tr>
        <td><img src="indexs_files/thumb-bot-left.gif" width="24" height="27"></td>
        <td><img src="indexs_files/thumb-bot.gif" width="160" height="27"></td>
        <td><img src="indexs_files/thumb-bot-right.gif" width="26" height="27"></td>
      </tr>
    </tbody></table></td>
  </tr>
  <tr>
    <td class="content" align="center"><a href="http://www.lagosstate.gov.ng/BRF.php">His Excellency <br>
      Mr. Babatunde Raji Fashola, SAN </a></td>
  </tr>
  <tr>
    <td class="content" align="center"><strong>Governor of Lagos State</strong></td>
  </tr>
  <tr>
    <td class="content" height="21">&nbsp;</td>
  </tr>
  <tr>
    <td class="content"><div class="actday style1" align="center">Financials</div></td>
  </tr>
  <tr>
    <td class="content">&nbsp;</td>
  </tr>
  <tr>
    <td class="content"><div align="center"><a href="http://www.lagosstate.gov.ng/Y2010BudgetAppraisal.pdf">YEAR 2010 BUDGET APPRAISAL</a></div></td>
  </tr>
  <tr>
    <td class="content">&nbsp;</td>
  </tr>
  <tr>
    <td class="content"><div align="center"></div></td>
  </tr>
  <tr>
    <td class="content"><div align="center"><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=695&amp;mnu=module&amp;mnusub=ministry&amp;mpid=25">YEAR 2010 APPROVED BUDGET</a> </div></td>
  </tr>
  <tr>
    <td class="content">&nbsp;</td>
  </tr>
  <tr>
    <td class="content"><div align="center"><a href="http://www.lagosstate.gov.ng/Y2010BUDGET.pdf"><strong>Year 2010 Abridge Annual Budget</strong></a></div></td>
  </tr>
  <tr>
    <td class="content">&nbsp;</td>
  </tr>
  <tr>
    <td class="content"><div align="center"><a href="http://www.lagosstate.gov.ng/CITIZEN_GUIDE.pdf">Citizen's Guide to Year 2010 Budget </a></div></td>
  </tr>
  <tr>
    <td class="content"><div align="center"></div></td>
  </tr>
  <tr>
    <td class="content"><div align="center"><a href="http://www.lagosstate.gov.ng/Y2010Q2MEPB3.pdf">YEAR 2010 2ND QUARTER BUDGET REVIEW </a></div></td>
  </tr>
  <tr>
    <td class="content"><div align="center"></div></td>
  </tr>
  <tr>
    <td class="content"><div align="center"><a href="http://www.lagosstate.gov.ng/Y2010Q2MEPB3.pdf">YEAR 2010 3RD QUARTER BUDGET REVIEW</a></div></td>
  </tr>
  <tr>
    <td class="content">&nbsp;</td>
  </tr>
  
  <tr>
    <td class="content"><div align="center"><a href="http://www.lagosstate.gov.ng/index.php?page=moduledetail&amp;mpid=43&amp;mnusub=ministry&amp;mnu=module">YEAR 2005 - 2008 FINANCIAL STATEMENTS</a> </div></td>
  </tr>
  <tr>
    <td class="content">&nbsp;</td>
  </tr>
  <tr>
    <td class="content"><div align="center"><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=610&amp;mnu=module&amp;mnusub=ministry&amp;mpid=25"><strong>Year 2009   Budget </strong></a></div></td>
  </tr>
  <tr>
    <td class="content">&nbsp;</td>
  </tr>
  <tr>
    <td class="content"><div align="center"><a href="http://www.lagosstate.gov.ng/indexbudget.php"><strong>Year 2008 Budget </strong></a></div></td>
  </tr>
  <tr>
    <td class="content">&nbsp;</td>
  </tr>
  <tr>
    <td class="content"><div align="center"><a href="http://www.lagosstate.gov.ng/uploads/INVESTMENT%20BROCHURE.pdf" target="_blank">Lagos State Investment Brochure </a></div></td>
  </tr>
  <tr>
    <td class="content">&nbsp;</td>
  </tr>
  <tr>
    <td class="content"><div align="center"><a href="http://www.lagosstate.gov.ng/uploads/INVESTMENT%20BROCHURE.pdf" target="_blank"></a><a href="http://www.stb.lagosstate.gov.ng/" target="_blank"><img src="indexs_files/stb.jpg" alt="Visit Our Site" longdesc="http://www.stb.lagosstate.gov.ng" border="0" width="161" height="28"></a></div></td>
  </tr>
  
  <tr>
    <td class="content" align="center" background="indexs_files/nav.gif">
      <div class="nav"> <a href="http://www.lagosstate.gov.ng/index.php?page=home" title="Home">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Lagos
Home
Page&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a> 
              <div class="clearer"><span></span></div>
    </div></td>
  </tr>
  <tr>
    <td class="content">
<ul id="menu">
      
          
          
      
                
      
      

      <li> <a href="#">Structures of Government</a>
            <ul style="display: block;">
              <!--              <li><a href="index.php?page=subpage&amp;spid=&amp;mnu=null"></a></li>
-->                              <li><a href="http://www.lagosstate.gov.ng/index.php?page=excolist&amp;mpid=117&amp;mnu=null"> The Executive</a></li>
              <li><a href="http://www.lagoshouseofassembly.gov.ng/">The Legislative</a></li>
              <li><a href="http://www.lagosjudiciary.gov.ng/">The Judiciary</a></li>
            </ul>
      </li>
      <li> <a href="#">Lagos Overview</a>
            <ul style="display: none;">
                            <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=9&amp;mnu=null">Information for Visitors</a></li>
                              <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=10&amp;mnu=null">Markets in Lagos State</a></li>
                              <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=11&amp;mnu=null">Country Information</a></li>
                              <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=12&amp;mnu=null">Population</a></li>
                              <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=13&amp;mnu=null">Geographical Area</a></li>
                              <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=14&amp;mnu=null">History of Lagos State</a></li>
                              <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=15&amp;mnu=null">Tourism Sites &amp; Scenes</a></li>
                              <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=16&amp;mnu=null">Investment Potentials</a></li>
                            </ul>
      </li>
      <li> <a href="#">Lagos Map </a>
            <ul style="display: none;">
              <li><a href="http://www.traxmap.com/maps/nigeria/LagosRoute/GOV1.ASP">Street Maps</a></li>
              <li><a href="http://www.traxmap.com/maps/nigeria/LagosRoute/csearch.asp">Map of Lagos</a></li>
            </ul>
      </li>
      <li> <a href="#">Directory</a>
            <ul style="display: none;">
                              <li><a href="http://www.lagosstate.gov.ng/index.php?page=dir&amp;dirc=3&amp;mnu=null">Banking</a></li>
                                  <li><a href="http://www.lagosstate.gov.ng/index.php?page=dir&amp;dirc=7&amp;mnu=null">Chambers of Commerce</a></li>
                                  <li><a href="http://www.lagosstate.gov.ng/index.php?page=dir&amp;dirc=6&amp;mnu=null">Embassies and High Commission in Nigeria</a></li>
                                  <li><a href="http://www.lagosstate.gov.ng/index.php?page=dir&amp;dirc=4&amp;mnu=null">Insurance</a></li>
                                  <li><a href="http://www.lagosstate.gov.ng/index.php?page=dir&amp;dirc=11&amp;mnu=null">International Airlines in Nigeria</a></li>
                                  <li><a href="http://www.lagosstate.gov.ng/index.php?page=dir&amp;dirc=8&amp;mnu=null">Nigeria Embassies And High Commissions Abroad</a></li>
                                  <li><a href="http://www.lagosstate.gov.ng/index.php?page=dir&amp;dirc=2&amp;mnu=null">Oil and Gas</a></li>
                                  <li><a href="http://www.lagosstate.gov.ng/index.php?page=dir&amp;dirc=10&amp;mnu=null">Private Domestic Airlines and Charter Air Services in Nigeria</a></li>
                                  <li><a href="http://www.lagosstate.gov.ng/index.php?page=dir&amp;dirc=9&amp;mnu=null">Professional Bodies in Nigeria</a></li>
                                  <li><a href="http://www.lagosstate.gov.ng/index.php?page=dir&amp;dirc=1&amp;mnu=null">Technology</a></li>
                              </ul>
      </li>
      <li> <a href="#">Important Links</a>
            <ul style="display: none;">
                            <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=18&amp;mnu=null">Lagos State Water Corporation</a></li>
                              <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=19&amp;mnu=null">Examination Fees &amp; Registration</a></li>
                              <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=20&amp;mnu=null">Lagos State Lands Bureau</a></li>
                              <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=21&amp;mnu=null">Public Documents</a></li>
                              <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=22&amp;mnu=null">Inaugural Speech of the Governor</a></li>
                              <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=23&amp;mnu=null">Revenue Complaints &amp; Information Unit</a></li>
                              <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=24&amp;mnu=null">Lekki Master Plan</a></li>
                              <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=724&amp;mnu=null">ENTERPRISE GIS</a></li>
                            </ul>
      </li>
      <li> <a href="#">Emergency Dials</a>
            <ul style="display: none;">
                            <li><a href="http://www.lagosstate.gov.ng/index.php?page=subpage&amp;spid=30&amp;mnu=null">Emergency Dials</a></li>
          </ul>
      </li>
      <li> <a href="#">Downloables/Archive</a>
            <ul style="display: none;">
              <li><a href="http://www.lagosstate.gov.ng/index.php?page=upload&amp;gcat=Video&amp;mnusub=general&amp;mpid=&amp;mnu=null">Video</a></li>
               <li><a href="http://www.lagosstate.gov.ng/index.php?page=upload&amp;gcat=Audio&amp;mnusub=general&amp;mpid=&amp;mnu=null">Audio</a></li>
             <li><a href="http://www.lagosstate.gov.ng/index.php?page=upload&amp;gcat=Image&amp;mnusub=general&amp;mpid=&amp;mnu=null">Images</a></li>
              <li><a href="http://www.lagosstate.gov.ng/index.php?page=upload&amp;gcat=Forms&amp;mnusub=general&amp;mpid=&amp;mnu=null">Downloadable Forms</a></li>
              <li><a href="http://www.lagosstate.gov.ng/index.php?page=upload&amp;gcat=Document&amp;mnusub=general&amp;mpid=&amp;mnu=null">Documents</a></li>
            </ul>
      </li>
    </ul></td>
  </tr>
  <tr>
    <td class="content" height="536"><p align="center">
      <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" align="middle" width="220" height="260">
        <param name="movie" value="images/e-Payment2.swf">
        <param name="quality" value="high">
        <embed src="indexs_files/e-Payment2.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" align="middle" width="220" height="260">
      </object>
    </p>
    <p align="center"><a href="http://www.lasg-ebs-rcm.com/" target="_blank">Click here for more information</a></p>    </td>
  </tr>
</tbody></table>
</td>
        <td bgcolor="#f2f8fd" valign="top"><span class="content">
          




	<script src="indexs_files/jquery-1.js" type="text/javascript"></script>
	<script src="indexs_files/menu.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="indexs_files/stylesheet.css">
<style type="text/css">
<!--
.style1 {color: #FF0000}
.style2 {font-size: 10px}
-->
</style>


<table width="100%">
  <tbody><tr>
    <td bgcolor="#deebf8" valign="top" width="361"><table width="63%">
      <tbody><tr>
        <td class="bigtextred">Welcome to Lagos </td>
      </tr>
      <tr>
        <td class="content" bgcolor="#ffffff"><p><span style="line-height: 115%; font-size: 8pt;"><a href="http://www.lagosstate.gov.ng/index.php?page=general&amp;gpid=15mnu=null"><span style="font-family: 'Arial','sans-serif';">ROAD &amp; TRANSPORTATION</span></a></span><span style="line-height: 115%; font-family: &quot;Arial&quot;,&quot;sans-serif&quot;; font-size: 8pt;"> <a href="http://www.lagosstate.gov.ng/index.php?page=general&amp;gpid=16mnu=null">ENVIRONMENT</a>&nbsp;<a href="http://www.lagosstate.gov.ng/index.php?page=general&amp;gpid=21mnu=null"><span style="color: rgb(0, 255, 0);">EDUCATION</span></a>&nbsp; <a href="http://www.lagosstate.gov.ng/index.php?page=general&amp;gpid=18mnu=null">HEALTH</a>&nbsp; <a href="http://www.lagosstate.gov.ng/index.php?page=general&amp;gpid=19mnu=null">WATER &amp; HOUSING&nbsp;</a> <a href="http://www.lagosstate.gov.ng/index.php?page=general&amp;gpid=20mnu=null"><span style="color: rgb(153, 204, 0);">RURAL &amp; RIVERING DEVELOPMENT</span></a> <a href="http://www.lagosstate.gov.ng/index.php?page=general&amp;gpid=17mnu=null">AGRICULTURE</a>&nbsp;<a href="http://www.lagosstate.gov.ng/index.php?page=general&amp;gpid=22mnu=null"><span style="color: rgb(153, 204, 0);"> LAW &amp; ORDER</span></a></span></p>
<p><br>
&nbsp;</p><a href="http://www.lagosstate.gov.ng/index.php?page=general&amp;gpid=9mnu=null"></a></td>
      </tr>
      <tr>
        <td background="indexs_files/divider.jpg" bgcolor="#ffffff" height="2"></td>
      </tr>
      <tr>
        <td class="mediumtextgreen" bgcolor="#ffffff" height="2"><strong>Clip of the Moment</strong></td>
      </tr>
      <tr>
        <td bgcolor="#ffffff" height="2"><script type="text/javascript" src="indexs_files/swfobject.js"></script>
	<script type="text/javascript">
		var s2 = new SWFObject("player.swf","ply","360","260","9","#FFFFFF");
		s2.addParam("allowfullscreen","true");
		s2.addParam("allownetworking","all");
		s2.addParam("allowscriptaccess","always");
		s2.addParam("flashvars","file=uploads/&image=preview.jpg");
		s2.write("container2");
	</script>
	<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="350" height="280">
      <param name="movie" value="images/health.swf">
      <param name="quality" value="high">
      <embed src="indexs_files/health.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="350" height="280">
	  </object></td>
      </tr>
      <tr>
        <td align="center"><table bgcolor="#ffffff" width="100%">
          <tbody><tr>
            <td colspan="3" class="bigtextgreen" align="left" bgcolor="#e6eef9">Our Activities</td>
          </tr>
          <tr>
            <td align="center" width="34%"><p><a href="http://www.lagosstate.gov.ng/index.php?page=moduledetail&amp;mpid=27&amp;mnusub=ministry&amp;mnu=module"><img src="indexs_files/icon_education.png" border="0" width="104" height="106"></a></p></td>
            <td align="center" width="33%"><a href="http://www.lagosstate.gov.ng/index.php?page=moduledetail&amp;mpid=37&amp;mnusub=ministry&amp;mnu=module"><img src="indexs_files/icon_transport.png" border="0" width="104" height="106"></a></td>
            <td align="center" width="33%"><a href="http://www.lagosstate.gov.ng/index.php?page=moduledetail&amp;mpid=32&amp;mnusub=ministry&amp;mnu=module"><img src="indexs_files/icon_health.png" border="0" width="104" height="106"></a></td>
          </tr>
          <tr>
            <td align="center"><span class="style1">Education</span></td>
            <td align="center" width="33%"><span class="style1">Transportation</span></td>
            <td align="center" width="33%"><span class="style1">Health</span></td>
          </tr>
          <tr>
            <td align="center"><a href="http://www.lagosstate.gov.ng/index.php?page=moduledetail&amp;mpid=22&amp;mnusub=ministry&amp;mnu=module"><img src="indexs_files/icon_lands.png" border="0" width="104" height="106"></a></td>
            <td align="center"><a href="http://www.lagosstate.gov.ng/index.php?page=moduledetail&amp;mpid=25&amp;mnusub=ministry&amp;mnu=module"><img src="indexs_files/icon_investment.png" border="0" width="104" height="106"></a></td>
            <td align="center"><a href="http://www.lagosstate.gov.ng/index.php?page=moduledetail&amp;mpid=29&amp;mnusub=ministry&amp;mnu=module"><img src="indexs_files/icon_environment.png" border="0" width="104" height="106"></a></td>
          </tr>
          <tr>
            <td class="style1" align="center">Lands</td>
            <td align="center"><span class="style1">Economy </span></td>
            <td class="style1" align="center">Environment</td>
          </tr>
        </tbody></table></td>
      </tr>
      <tr>
        <td align="center"><table class="generaltablebg" bgcolor="#f5f7fa" width="100%">
          <tbody><tr>
            <td class="bigtextgreen" align="left" bgcolor="#e6eef9">Lagos Mega City</td>
          </tr>
          <tr>
            <td align="left" width="84%"><p><span class="content"><p>Welcome To New Lagos</p>
<p>One of Lagos State Mega City Projects:</p>
<p><a href="http://www.lagos-airport.com/">New Lagos Airport Project</a></p>
<p><br>
&nbsp;</p></span> <a href="http://www.lagosstate.gov.ng/index.php?page=general&amp;gpid=10&amp;mnu=null">...more</a></p></td>
          </tr>
        </tbody></table></td>
      </tr>
      <tr>
        <td align="center"><table class="generaltablebg" bgcolor="#f5f7fa" width="100%">
          <tbody><tr>
            <td class="mediumtextgreen" align="left" bgcolor="#e6eef9">Public-Private Partnership Programmes </td>
          </tr>
          <tr>
            <td align="left" width="84%"><p><span class="content"><p><a href="http://www.lagosstateppp.gov.ng/">Click here to visit our site</a><br>
&nbsp;</p></span></p></td>
          </tr>
        </tbody></table></td>
      </tr>
      <tr>
        <td align="center"><div class="mediumtextgreen" align="left"><a href="http://www.lagosstate.gov.ng/HOUSEHOLD%20SURVEY%202010.pdf">2010 Lagos State Household Survey </a></div></td>
      </tr>
      <tr>
        <td align="center">&nbsp;</td>
      </tr>
      <tr>
        <td align="center"><table class="generaltablebg" bgcolor="#f5f7fa" width="100%">
          <tbody><tr>
            <td colspan="2" class="bigtextgreen" align="left" bgcolor="#e6eef9" width="100%"><a href="http://www.lagosstate.gov.ng/FIFAU17WORLDCUP.pdf" class="mediumtextgreen">FIFA UNDER-17 WORLD CUP NIGERIA 2009 LOC LAGOS SUB SEAT FINAL REPORT</a></td>
          </tr>
          
        </tbody></table></td>
      </tr>
    </tbody></table></td>
    <td bgcolor="#dee9f6" valign="top" width="283"><table cellpadding="0" cellspacing="0" width="100%">
      <tbody><tr>
        <td align="center" width="33%"><a href="mailto:enquiries@lagosstate.gov.ng"><img src="indexs_files/enquiries.jpg" alt="Submit Enquiries Here" border="0" width="80" height="24"></a><a href="mailto:enquiries@lagosstate.gov.ng"></a></td>
        <td align="center" width="28%"><a href="mailto:complaints@lagosstate.gov.ng"><img src="indexs_files/Complaints.jpg" border="0" width="80" height="24"></a><a href="mailto:complaints@lagosstate.gov.ng"></a></td>
        <td align="center" width="39%"><a href="mailto:feedback@lagosstate.gov.ng"><img src="indexs_files/Feedback.jpg" border="0" width="80" height="24"></a></td>
      </tr>
      <tr>
        <td align="center">&nbsp;</td>
        <td align="center">&nbsp;</td>
        <td align="center">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="2" align="center" bgcolor="#999999" valign="middle" height="39"><div align="right"><a href="https://dove.lagosstate.gov.ng/owa"><img src="indexs_files/email.jpg" border="0" width="56" height="38"></a></div></td>
        <td align="center" bgcolor="#999999" valign="middle" height="39"><div align="left"><a href="https://dove.lagosstate.gov.ng/owa">Official Email</a></div></td>
      </tr>
      <tr>
        <td align="center">&nbsp;</td>
        <td align="center">&nbsp;</td>
        <td align="center">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="3" align="center"><img src="indexs_files/news.png" align="baseline" width="278" height="46"></td>
      </tr>
      <tr>
        <td colspan="3" bgcolor="#ffffff">




<table width="100%">
            <tbody><tr>
        <td class="contentnormal" bgcolor="#ffffff"><span class="smAllnews">17.03.2011          </span><br>
          FASHOLA UNVEILS 2.4MILLION SQUARE METRES OF RECLAIMED LAND IN NEW EKO ATLANTIC CITY </td>
      </tr>
      <tr>
        <td class="contentnormal" align="right" valign="top" height="18"><a href="http://www.lagosstate.gov.ng/index.php?page=news&amp;nid=941">more</a></td>
      </tr>
      <tr>
        <td class="contentnormal" background="indexs_files/divider.jpg" height="2"></td>
      </tr>
            <tr>
        <td class="contentnormal" bgcolor="#ffffff"><span class="smAllnews">17.03.2011          </span><br>
          EBONYI RESIDENTS IN LAGOS EMBRACE ACN, FASHOLA </td>
      </tr>
      <tr>
        <td class="contentnormal" align="right" valign="top" height="18"><a href="http://www.lagosstate.gov.ng/index.php?page=news&amp;nid=940">more</a></td>
      </tr>
      <tr>
        <td class="contentnormal" background="indexs_files/divider.jpg" height="2"></td>
      </tr>
            <tr>
        <td class="contentnormal" bgcolor="#ffffff"><span class="smAllnews">17.03.2011          </span><br>
          LAGOS HOLDS FIRST WASTE WATER INVESTMENT FORUM </td>
      </tr>
      <tr>
        <td class="contentnormal" align="right" valign="top" height="18"><a href="http://www.lagosstate.gov.ng/index.php?page=news&amp;nid=939">more</a></td>
      </tr>
      <tr>
        <td class="contentnormal" background="indexs_files/divider.jpg" height="2"></td>
      </tr>
            <tr>
        <td class="contentnormal" bgcolor="#ffffff"><span class="smAllnews">16.03.2011          </span><br>
          IBEJU-LEKKI HOLDS KEY TO NATION&#8217;S FUTURE PROSPERITY,SAYS FASHOLA </td>
      </tr>
      <tr>
        <td class="contentnormal" align="right" valign="top" height="18"><a href="http://www.lagosstate.gov.ng/index.php?page=news&amp;nid=938">more</a></td>
      </tr>
      <tr>
        <td class="contentnormal" background="indexs_files/divider.jpg" height="2"></td>
      </tr>
            <tr>
        <td class="contentnormal" bgcolor="#ffffff"><span class="smAllnews">15.03.2011          </span><br>
          LAGOS MARKS COMMONWEALTH DAY</td>
      </tr>
      <tr>
        <td class="contentnormal" align="right" valign="top" height="18"><a href="http://www.lagosstate.gov.ng/index.php?page=news&amp;nid=937">more</a></td>
      </tr>
      <tr>
        <td class="contentnormal" background="indexs_files/divider.jpg" height="2"></td>
      </tr>
            <tr>
        <td class="contentnormal" bgcolor="#ffffff"><span class="smAllnews">15.03.2011          </span><br>
          FASHOLA MEETS 507 NEWLY EMPLOYED GRADUATE TEACHERS </td>
      </tr>
      <tr>
        <td class="contentnormal" align="right" valign="top" height="18"><a href="http://www.lagosstate.gov.ng/index.php?page=news&amp;nid=934">more</a></td>
      </tr>
      <tr>
        <td class="contentnormal" background="indexs_files/divider.jpg" height="2"></td>
      </tr>
          
</tbody></table>






<table border="0" width="100%">
  <tbody><tr>
    <td align="right"><a href="http://www.lagosstate.gov.ng/index.php?page=newsall&amp;"><strong>View All News</strong></a></td>
  </tr>
</tbody></table>
</td>
      </tr>
      <tr>
        <td colspan="3">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="3"><table bgcolor="#ffffff" width="100%">
          <tbody><tr>
            <td class="bigtextblue" align="left">Events</td>
          </tr>
          <tr>
            <td align="center" width="84%">
			            <table border="0" width="100%">
              <tbody><tr>
                <td><a href="http://www.lagosstate.gov.ng/index.php?mnu=module...ministry...%20-&amp;emonth=2&amp;eyear=2011">prev</a></td>
                <td align="right"><a href="http://www.lagosstate.gov.ng/index.php?emonth=4&amp;eyear=2011">next</a></td>
              </tr>
            </tbody></table>
			
			<script type="text/javascript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<table class="month" width="100%">  <tbody><tr><th colspan="7">March - 2011</th></tr>  <tr class="days"><td>Mo</td><td>Tu</td><td>We</td><td>Th</td><td>Fr</td><td>Sa</td><td>Su</td></tr><tr><td>&nbsp;</td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=1&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">1</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=2&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">2</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=3&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">3</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=4&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">4</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=5&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">5</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=6&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">6</a></td></tr><tr><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=7&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">7</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=8&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">8</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=9&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">9</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=10&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">10</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=11&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">11</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=12&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">12</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=13&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">13</a></td></tr><tr><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=14&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">14</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=15&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">15</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=16&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">16</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=17&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">17</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=18&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">18</a></td><td class="actday"><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=19&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">19</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=20&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">20</a></td></tr><tr><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=21&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">21</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=22&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">22</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=23&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">23</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=24&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">24</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=25&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">25</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=26&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">26</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=27&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">27</a></td></tr><tr><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=28&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">28</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=29&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">29</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=30&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">30</a></td><td><a href="#" onclick="MM_openBrWindow('showeventlist.php?index.php?page=event&amp;evday=31&amp;evmon=3&amp;evyear=2011','Events','scrollbars=yes,width=500,height=500')">31</a></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></tbody></table></td>
          </tr>
        </tbody></table></td>
      </tr>
      
      <tr>
        <td colspan="3"><table bgcolor="#ffffff" border="0" width="100%">
          <tbody><tr>
            <td class="smAllnews" colspan="2"><em>Events for 
                  2011-19-03            </em></td>
            </tr>
                                <tr>
              <td colspan="2"><em>none</em></td>
            </tr>
            
                </tbody></table></td>
      </tr>
      <tr>
        <td colspan="3">&nbsp;</td>
      </tr>
      <tr>
        <td colspan="3"><table bgcolor="#ffffff" width="100%">
          <tbody><tr>
            <td class="bigtextblue" align="left"><div align="center">Event of the Month</div></td>
          </tr>
          <tr>
            <td class="generalbody" align="left" width="84%"><div align="center"><a href="http://www.lagosstate.gov.ng/showeventmonth.php?eventidd=48" target="_blank"><img src="indexs_files/event_month_201103141840274d7e530be3d5cPix_0011.jpg" border="0" width="250"></a></div></td>
          </tr>
        </tbody></table></td>
      </tr>
      <tr>
        <td colspan="3"><div class="style2" align="center">
          <p align="justify"><a href="http://www.lagosstate.gov.ng/showeventmonth.php?eventidd=48">The
picture shows cross section of the 507 newly recruited graduate
teachers under the Special Education Intervention Programme of the
State Government during their Inauguration by the Lagos State Governor,
Mr. Babatunde Fashola (SAN) at the Lagos House, Ikeja, on Monday, March
14, 2011. INSET: Lagos State Governor Mr. Babatunde Fashola SAN (2nd
left), his Deputy, Princess Adebisi Sarah Sosan (2nd right),
Commissioner for Science and Technology, Dr. Femi Hamzat (left) and
Commissioner for Budget and Economic Planning, Mr. Ben Akabueze (right)
during the Inauguration.</a></p>
          </div></td>
      </tr>
      <tr>
        <td colspan="3"><table bgcolor="#f5f7fa" width="100%">
          <tbody><tr>
            <td class="bigtextblue" align="left">Special Annoucements</td>
          </tr>
                      <tr>
                <td class="generalbody" align="left" width="84%"><p class="content"><a href="http://www.lagosstate.gov.ng/showspecial.php?eventidd=11" target="_blank">1. MINISTRY OF PHYSICAL PLANNING AND URBAN DEVELOPMENT (PUBLIC NOTICE)

DEVELOPMENT OF COMPUTER BUSINESS AND ALLIED BUSINESS PARK AT KATANGOWA AND A NEW 
KATANGOWA MARKET AT AMIKANLE BOTH IN AGBADO OKE-ODO LOCAL COUNCIL DEVELOPMENT AREA OF LAGOS STATE.
</a></p></td>
            </tr>
                        <tr>
                <td class="generalbody" align="left" width="84%"><p class="content"><a href="http://www.lagosstate.gov.ng/showspecial.php?eventidd=9" target="_blank">2. STATE FUNCTIONS/ EVENTS AND PUBLIC HOLIDAYS IN YEAR 2011</a></p></td>
            </tr>
                        <tr>
                <td class="generalbody" align="left" width="84%"><p class="content"><a href="http://www.lagosstate.gov.ng/showspecial.php?eventidd=8" target="_blank">3. PUBLIC PRESENTATION OF THE DRAFT ALIMOSHO MODEL CITY PLAN (2010 -2020)</a></p></td>
            </tr>
                        <tr>
                <td class="generalbody" align="left" width="84%"><p class="content"><a href="http://www.lagosstate.gov.ng/showspecial.php?eventidd=7" target="_blank">4. PRE-QUALIFICATION AND TENDER FOR CONSTRUCTION OF 6-UNITS RESIDENTIAL BUILDING TO SERVE AS TRANSIT ACCOMODATION</a></p></td>
            </tr>
                        <tr>
                <td class="generalbody" align="left" width="84%"><p class="content"><a href="http://www.lagosstate.gov.ng/showspecial.php?eventidd=6" target="_blank">5. PARTNERS ACTIVITIES FOR 2010 WORLD MALARIA DAY</a></p></td>
            </tr>
                        <tr>
                <td class="generalbody" align="left" width="84%"><p class="content"><a href="http://www.lagosstate.gov.ng/showspecial.php?eventidd=5" target="_blank">6. Backlogs of Building Plan Applications Submitted between 2004-2008  </a></p></td>
            </tr>
                        <tr>
                <td class="generalbody" align="left" width="84%"><p class="content"><a href="http://www.lagosstate.gov.ng/showspecial.php?eventidd=3" target="_blank">7. DONATION TOWARDS HAITI EARTHQUAKE VICTIMS</a></p></td>
            </tr>
                        <tr>
                <td class="generalbody" align="left" width="84%"><p class="content"><a href="http://www.lagosstate.gov.ng/showspecial.php?eventidd=2" target="_blank">8. LIST OF LAGOS STATE GOVERNMENT DESIGNATED REVENUE COLLECTING BANKS</a></p></td>
            </tr>
                        <tr>
                <td class="generalbody" align="left" width="84%"><p class="content"><a href="http://www.lagosstate.gov.ng/showspecial.php?eventidd=1" target="_blank">9. Biometric Verification Excemption for Pensioners Residing Abroad</a></p></td>
            </tr>
                    </tbody></table></td>
      </tr>
    </tbody></table></td>
  </tr>
</tbody></table>










</span></td>
        </tr>
      
    </tbody></table></td>
  </tr>
</tbody></table><br>
<table align="center" background="indexs_files/bgbg.gif" border="0" cellpadding="0" cellspacing="0" width="100%">
  
  <tbody><tr>
    <td align="center" height="45">� Copyright 2011, Lagos State Government, Nigeria. All rights reserved</td>
  </tr>
</tbody></table>










</body></html>