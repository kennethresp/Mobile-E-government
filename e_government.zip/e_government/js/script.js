function argument()
{
	var name=$('#name').val();
	var state=$('#state').val();
	var arg=$('#arg').val();
	if(name==""){
		alert("Be a good Citizen  and type your name");
	}
	else if(state=="")
	{
		alert("Be a good Citizen  and type your State");
	}
	else if(arg=="")
	{
		alert("Be a good Citizen, Make your Point");
	}
	else
	{
		$('#displayArg').append('<div class="ui-corner-all custom-corners" style="word-wrap: break-word;"><div class="ui-bar ui-bar-a"> <h3> <font color="#FFFFFF"> '+name+' <img src="icons/123-id-card.png"> '+state+'</font> </h3> </div>  <div class="ui-body ui-body-a"><b>'+arg+'</b><br><hr> </div></div><br>');
	}
	}