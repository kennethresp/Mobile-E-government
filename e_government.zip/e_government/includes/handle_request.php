 <?php
session_start();

require_once("dbconnect.php");
require_once("class_update.php");
require_once("class_select.php");
require_once("class_insert.php");
require_once("class_delete.php");

$other=new other;
$select=new selectData;
$insert=new insertData;
$update=new updateData;
$delete=new deleteData;
if(isset($_SESSION['member_id']))
{
	$idx=explode("/",$_SESSION['member_id']);
	$member_id=$idx[0];
}


if(isset($_GET['_mode']))
{
	$page=mysql_real_escape_string($_GET['_mode']);
	
	foreach ($_REQUEST as $key => $value):
		   $value =trim($value);
		   //$vars .= "$key = $value<br />";
		   $$key=$value;
	endforeach;
	
	if($page=="userLogin")
	{
		if(empty($remember))
			$remember=0;
		if($select->Login($username,$password,$remember,"userLogin")==false)
			echo "Invalid Login Details";
		else
			echo 1;
	}
	else if($page=="userReg")
	{
		$pass=rand(00000000,99999999);
		$pass=md5($pass);
		$member_code="MKTC".$pass."BS";
		$member_code=md5($member_code);
		
		if(!isset($inputNotification))
			$inputNotification=0;
			
		echo $insert->userReg($member_code,ucwords($inputFullname),$inputEmail,$inputPhone,$inputSpecialization,$inputUsername,$inputPassword,$inputNotification);
	}else if($page=="updateBio")
	{
		
		echo $update->updateBio($member_id,ucwords($inputFullname),$inputEmail,$inputPhone,$inputUsername);
	}else if($page=="updateUserPassword")
	{		
		$pword=md5($inputCurPass);
		$pword.=md5("marketcity");
		$inputCurPass=md5($pword);
		
		$pword=md5($inputConfirmPass);
		$pword.=md5("marketcity");
		$newPassword=md5($pword);
		
		if($inputConfirmPass!=$inputNewPass){
			echo json_encode(array("success"=>0,"Msg"=>"Password Mismatch. Ensure Your new password matches with comfirmed password"));
		}elseif($select->checkUserPass($member_id,$inputCurPass)){
			echo json_encode(array("success"=>0,"Msg"=>"You did not type your current password correctly."));
		}else{
		
			echo $update->updateUserPassword($member_id,$newPassword);
		}
	}
	else if($page=="loaduser")
	{
		$user_number="07035252276";
		echo $select->loaduser($user_number);
	}
	else if($page=="loadAlluser")
	{
		$myPhone=$_GET['myPhone'];
		
		echo $select->loadAlluser($myPhone);
	}
	else if($page=="followUserUpdate")
	{
		$count=$_GET['count'];
		$FollowedNumber=$_GET['FollowedNumber'];
		$FollowerNumber=$_GET['FollowerNumber'];
		
		echo $update->followUserUpdate($FollowedNumber,$FollowerNumber,$count);
	}
	else if($page=="readContactToDBase")
	{
		$Number=$_GET['Number'];
		
		echo $select->readContactToDBase($Number);
	}
	else if($page=="comment")
	{
		$commentByUser=mysql_escape_string($_GET['commentByUser']);
		$UserName=$_GET['UserName'];
		$date=$_GET['date'];
		$school=$_GET['school'];
		$domain_school=$_GET['domain_school'];
		$phoneNumber=$_GET['phoneNumber'];
		$profileLodge=$_GET['profileLodge'];
		echo $insert->comment($commentByUser,$UserName,$date,$school,$domain_school,$phoneNumber,$profileLodge);
	}
	else if($page=="imageComment")
	{
		$commentByUser=mysql_escape_string($_GET['commentByUser']);
		$UserName=$_GET['UserName'];
		$date=$_GET['date'];
		$school=$_GET['school'];
		$domain_school=$_GET['domain_school'];
		$phoneNumber=$_GET['phoneNumber'];
		$profileLodge=$_GET['profileLodge'];
		echo $select->imageComment($commentByUser,$UserName,$date,$school,$domain_school,$phoneNumber,$profileLodge);
	}
		else if($page=="checkForUploaded")
	{
		$commentByUser=mysql_escape_string($_GET['commentByUser']);
		$UserName=$_GET['UserName'];
		$date=$_GET['date'];
		$school=$_GET['school'];
		$domain_school=$_GET['domain_school'];
		$phoneNumber=$_GET['phoneNumber'];
		$profileLodge=$_GET['profileLodge'];
		echo $select->checkForUploaded($commentByUser,$UserName,$date,$school,$domain_school,$phoneNumber,$profileLodge);
	}
	else if($page=="subcomment")
	{
		$commentByUser=mysql_escape_string($_GET['commentByUser']);
		$UserName=mysql_escape_string($_GET['UserName']);
		$date=mysql_escape_string($_GET['date']);
		$id=$_GET['id'];
		$domain_school=$_GET['domain_school'];
		$profileLodge=$_GET['profileLodge'];
		$phoneNumber=$_GET['phoneNumber'];
		echo $insert->subcomment($commentByUser,$UserName,$date,$id,$domain_school,$profileLodge,$phoneNumber);
	}
	else if($page=="SbtnCreateGroup")
	{
		$SgroupName=mysql_escape_string($_GET['SgroupName']);
		$UserName=mysql_escape_string($_GET['name']);
		$profileSchool=$_GET['school'];
		$profileLodge=$_GET['lodge'];
		$phoneNumber=$_GET['Number'];
		echo $insert->SbtnCreateGroup($SgroupName,$UserName,$date,$profileSchool,$profileLodge,$phoneNumber);
	}
	else if($page=="DbtnCreateGroup")
	{
		$SgroupName=mysql_escape_string($_GET['SgroupName']);
		$UserName=mysql_escape_string($_GET['name']);
		$profileSchool=$_GET['school'];
		$profileLodge=$_GET['lodge'];
		$phoneNumber=$_GET['Number'];
		$groupDept=$_GET['groupDept'];
		echo $insert->DbtnCreateGroup($SgroupName,$UserName,$date,$profileSchool,$profileLodge,$phoneNumber,$groupDept);
	}
	else if($page=="joinGroup")
	{
		$id=mysql_escape_string($_GET['id']);
		$UserName=mysql_escape_string($_GET['name']);
		$profileSchool=$_GET['school'];
		$profileLodge=$_GET['lodge'];
		$phoneNumber=$_GET['Number'];
		echo $select->joinGroup($id,$UserName,$date,$profileSchool,$profileLodge,$phoneNumber);
	}
	else if($page=="LoadGroups")
	{
		$domain_school=$_GET['domain_school'];
		echo $select->LoadGroups($domain_school);
	}
	else if($page=="LoadUserGroups")
	{
		$domain_school=$_GET['domain_school'];
		$phoneNumber=$_GET['Number'];
		echo $select->LoadUserGroups($domain_school,$phoneNumber);
	}
	else if($page=="loadGroupContent")
	{
		$GnumOfPAge=$_GET['GnumOfPAge'];
		$id=$_GET['id'];
		echo $select->loadGroupContent($GnumOfPAge,$id);
	}
	else if($page=="Gcomment")
	{
		$commentByUser=mysql_escape_string($_GET['commentByUser']);
		$UserName=$_GET['UserName'];
		$date=$_GET['date'];
		$school=$_GET['school'];
		$id=$_GET['id'];
		$phoneNumber=$_GET['phoneNumber'];
		$profileLodge=$_GET['profileLodge'];
		echo $insert->Gcomment($commentByUser,$UserName,$date,$school,$id,$phoneNumber,$profileLodge);
	}
	else if($page=="loaduserlodge")
	{
		$user_number="07035252276";
		echo $select->loadLodgeName($user_number);
	}
	else if($page=="loadComment")
	 { 
	 
	  $domain_school=$_GET['domain_school'];
		$numOfPAge=$_GET['numOfPAge'];
		$phoneNumber=$_GET['phoneNumber'];
		echo $select->loadComment($numOfPAge,$domain_school,$phoneNumber);
	}
	else if($page=="loadUserProduct")
	{
		$phone=$_GET['phone'];
		$per_p=$_GET['per_p'];
		echo $select->loadUserProduct($per_p,$phone);
	}
	else if($page=="deletePost")
	{
		
		$id=$_GET['id'];
		echo $delete->deletePost($id);
	}
	else if($page=="changeName")
	{
		$phone=$_GET['phone'];
		$name=$_GET['name'];
		echo $update->changeName($name,$phone);
	}
	else if($page=="checkForUploadedPix")
	{
		
		$phoneNumber=$_GET['phoneNumber'];
		echo $select->checkForUploadedPix($phoneNumber);
	}
	else if($page=="followUser")
	{
		$count=$_GET['count'];
		$FollowedNumber=$_GET['FollowedNumber'];
		$FollowerNumber=$_GET['FollowerNumber'];
		echo $insert->followUser($FollowedNumber,$FollowerNumber,$count);
	}
	else if($page=="loaddateline")
	{
		$per_p=$_GET['per_p'];
		echo $select->loaddateline($per_p);
	}
	else if($page=="loadAdvert")
	{
		$school=$_GET['school'];
		echo $select->loadAdvert($school);
	}
	else if($page=="loaddatelineV")
	{
		$type=$_GET['type'];
		$per_pV=$_GET['per_pV'];
		echo $select->loaddatelineV($per_pV,$type);
	}
	else if($page=="followcount")
	{
		$number=$_GET['number'];
		echo $select->followcount($number);
	}
	else if($page=="deleteLectureTimeTable")
	{
		$myPhone=$_GET['myPhone'];
		echo $delete->deleteLectureTimeTable($myPhone);
	}
	else if($page=="deleteReadingTimeTable")
	{
		$myPhone=$_GET['myPhone'];
		echo $delete->deleteReadingTimeTable($myPhone);
	}
	else if($page=="myShop")
	{
		$phone=$_GET['phone'];
		echo $select->myShop($phone);
	}
	else if($page=="changePassword")
	{    $phone=$_GET['phone'];
		$newpass=$_GET['newpass'];
		
		echo $update->changePassword($phone,$newpass);
	}
	else if($page=="myShopCollect")
	{
		$phone=$_GET['phone'];
		$pin=$_GET['pin'];
		echo $select->myShopCollect($pin,$phone);
	}
	else if($page=="displayVacant")
	{
		$per_pV=$_GET['per_pV'];
		$type=$_GET['type'];
		echo $select->displayVacant($per_pV,$type);
	}
	else if($page=="saveRforLodge")
	{	$qst1=$_GET['qst1'];
		$qst2=$_GET['qst2'];
		$qst3=$_GET['qst3'];
		$qst4=$_GET['qst4'];
		$number=$_GET['number'];
		$name=$_GET['name'];
		echo $insert->saveRforLodge($qst1,$qst2,$qst3,$qst4,$number,$name);
	}
	else if($page=="alarmSetting")
	{
		$myPhone=$_GET['myPhone'];
		$op=$_GET['op'];
		echo $update->alarmSetting($op,$myPhone);
	}
	else if($page=="loadDeptMate")
	{
		$profileDept=$_GET['profileDept'];
		$myphone=$_GET['myphone'];
		$domain_school=$_GET['domain_school'];
		echo $select->loadDeptMate($profileDept,$myphone,$domain_school);
	}
	else if($page=="otherSchooldepartment")
	{
		$profileDept=$_GET['profileDept'];
		$myphone=$_GET['myphone'];
		$domain_school=$_GET['domain_school'];
		echo $select->otherSchooldepartment($profileDept,$myphone,$domain_school);
	}
	else if($page=="loadSearchProduct")
	{
		$phone=$_GET['phone'];
		$per_p=$_GET['per_p'];
		$searchvalue=$_GET['searchvalue'];
		echo $select->loadSearchProduct($per_p,$searchvalue,$phone);
	}
	else if($page=="myShopDelete")
	{
		$phone=$_GET['phone'];
		$pin=$_GET['pin'];
		$pix=$_GET['pix'];
	     unlink("uploads/".$pix);
		echo $delete->myShopDelete($pin,$phone,$pix);
		
	}
	else if($page=="followUserCheck")
	{
		$Number=$_GET['Number'];
		echo $select->followUserCheck($Number);
	}
	else if($page=="searchA")
	{   $phone=$_GET['phone'];
		$sechA=$_GET['sechA'];
		echo $select->searchA($sechA,$phone);
	}

	else if($page=="loadalllodges")
	{
		$domain_school=$_GET['domain_school'];
		echo $select->loadAllLodges($domain_school);
	}
	else if($page=="loadallSlodges")
	{
		$domain_school=$_GET['domain_school'];
		echo $select->loadallSlodges($domain_school);
	}
	else if($page=="sendGroupChat")
	{   $domain_school=$_GET['domain_school'];
		$message=$_GET['message'];
		$name=$_GET['name'];
		$date=$_GET['date'];
        $senderNumber=$_GET['senderNumber'];
		$lodgeId=$_GET['lodgeId'];
		echo $insert->sendGroupChat($name,$message,$date,$senderNumber,$domain_school,$lodgeId);
		
	}
	else if($page=="send")
	{   $recievername=$_GET['recievername'];
		$message=$_GET['message'];
		$name=$_GET['name'];
		$date=$_GET['date'];
        $senderNumber=$_GET['senderNumber'];
		$recieverNumber=$_GET['recieverNumber'];
		echo $insert->send($name,$message,$date,$senderNumber,$recieverNumber,$recievername);
		
	}
	else if($page=="saveProduct")
	{   $pname=$_GET['pname'];
		$pPrice=$_GET['pPrice'];
		$pDesc=$_GET['pDesc'];
		$pin=$_GET['pin'];
        $phone=$_GET['phone'];
		 $myName=$_GET['myName'];
		 $profileId=$_GET['profileId'];
		 
		echo $insert->saveProduct($pname,$pPrice,$pDesc,$pin,$phone,$myName,$profileId);
		
	}
	else if($page=="loginPhone")
	{
		$phone=$_GET['phone'];
	$password=$_GET['password'];

		echo $select->loginPhone($phone,$password);
		
	}
	else if($page=="LoadUser")
	{
		$id_user=$_GET['id_user'];
	

		echo $select->LoadUser($id_user);
		
	}
	else if($page=="LodgeMate")
	{
		$lodge=$_GET['lodge'];
	    $phone=$_GET['phone'];
		echo $select->LodgeMate($lodge,$phone);
	}
	else if($page=="recenChat")
	{
		
	    $phone=$_GET['phone'];
		echo $select->recentChatlist($phone);
	}
	else if($page=="updateChat")
	{
		$Sender=$_GET['Sender'];
	    $reciever=$_GET['reciever'];

		echo $select->updateChat($Sender,$reciever);
		
	}
	else if($page=="loadSearchLodge")
	{
		$searchvalue=$_GET['searchvalue'];
	  $domain_school=$_GET['domain'];

		echo $select->loadSearchLodge($searchvalue,$domain_school);
		
	}
	else if($page=="checkPhone")
	{
		$Phone=$_GET['Phone'];
	  

		echo $select->checkPhone($Phone);
		
	}
	else if($page=="updateChatBySeconds")
	{   
	    $myname=$_GET['myname'];
	    $recievername=$_GET['recievername'];
	    $phone=$_GET['phone'];
        $myphone=$_GET['myphone'];
		echo $select->updateChatBySeconds($phone,$myphone,$recievername,$myname);
		
	}
	else if($page=="updateChatGroupBySeconds")
	{   
	    $lodgeGroupId=$_GET['lodgeGroupId'];
	   $senderNumber=$_GET['senderNumber'];
		echo $select->updateChatGroupBySeconds($lodgeGroupId,$senderNumber);
		
	}
	else if($page=="updateChatBySeconds2")
	{   
	    $myname=$_GET['myname'];
	    $recievername=$_GET['recievername'];
	    $phone=$_GET['phone'];
        $myphone=$_GET['myphone'];
		echo $select->updateChatBySeconds2($phone,$myphone,$recievername,$myname);
		
	}
	else if($page=="loadAnotherLodgeMate")
	{   
	    $lodgId=$_GET['lodgId'];
	    $myPhone=$_GET['myPhone'];
		echo $select->loadAnotherLodgeMate($lodgId,$myPhone);
		
	}
	else if($page=="viewProfile")
	{   
	    $profileUserFullname="mm";
	   $profileUserPhone=$_GET['profileUserPhone'];
		echo $select->viewProfile($profileUserFullname,$profileUserPhone);
		
	}
	else if($page=="lodgeGossip")
	{   
	    $gossip=$_GET['gossip'];
	    $mylodge=$_GET['mylodge'];
	    $myName=$_GET['myName'];
		$date=$_GET['date'];
		echo $insert->lodgeGossip($gossip,$mylodge,$myName,$date);
		
	}
	else if($page=="updateGossip")
	{   
	    $mylodge=$_GET['mylodge'];
		echo $select->updateGossip($mylodge);
		
	}
	else if($page=="updateStatus")
	{   $myPhone=$_GET['myPhone'];
	    $newStatus=$_GET['newStatus'];
		echo $update->updateStatus($newStatus,$myPhone);
		
	}
	else if($page=="setTimeTable")
	{   
	    $type=$_GET['type'];
	    $coscode=$_GET['coscode'];
	    $venue=$_GET['venue'];
		$day=$_GET['day'];
		$ap=$_GET['ap'];
		$frm=$_GET['frm'];
		$to=$_GET['to'];
		$myPhone=$_GET['phone'];
		echo $insert->setTimeTable($type,$coscode,$venue,$day,$ap,$frm,$to,$myPhone);
		
	}
	else if($page=="setTimeTableExma")
	{   
	    $type=$_GET['type'];
	    $coscode=$_GET['coscode'];
	    $venue=$_GET['venue'];
		$day=$_GET['day'];
		$tym=$_GET['tym'];
		
		echo $insert->setTimeTableExma($type,$coscode,$venue,$day,$tym,$myPhone);
		
	}
	else if($page=="register")
	{   
	    $lodge=$_GET['lodge'];
	    $school=$_GET['school'];
	    $fullname=$_GET['fullname'];
		$pwd=$_GET['pwd'];
		$Checknumber=$_GET['Checknumber'];
		
		 $sex=$_GET['sex'];
		$college=$_GET['college'];
		$dept=$_GET['dept'];
		echo $insert->register($lodge,$school,$fullname,$pwd,$Checknumber,$sex,$college,$dept);
		
	}
	else if($page=="loadAlodge")
	{   
	    $school=$_GET['school'];
	 
		
		echo $select->loadAlodge($school);
		
	}
	else if($page=="SloadAlodge")
	{   
	    $school=$_GET['school'];
	 
		$sLodge=$_GET['sLodge'];
		echo $insert->SloadAlodge($school,$sLodge);
		
	}
	else if($page=="alarm")
	{   
	    $myPhone=$_GET['myPhone'];
	 
		
		echo $select->alarm($myPhone);
		
	}
	else if($page=="readTimeLectures")
	{   
	    $myPhone=$_GET['myPhone'];
	 
		
		echo $select->readTimeLectures($myPhone);
		
	}
	else if($page=="readTimeTableR")
	{   
	    $myPhone=$_GET['myPhone'];
	 
		
		echo $select->readTimeTableR($myPhone);
		
	}
	else if($page=="changePicture")
	{  
	     $myPhone=$_GET['myPhone'];
		 
		 $fileArray=$_FILES['inputPicture'];
				$folder="users";
		$data=$insert->imageUpload($fileArray,$folder);
			
			if($data['success']==0){//error occured
				return $data;
			}else{
				$pimage= $data['Msg'];
				$update->updatePics($myPhone,$pimage);
			}
		 
		 
		 
	
	}
}
?>