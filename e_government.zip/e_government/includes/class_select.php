<?php

class selectData extends dbconnect
{
	private $output;
	private $output2;
	private $url;
	public function __construct(){
		parent::__construct();	
	}
	//login function
	public function Login($username,$password,$remember,$category)
	{
		$pword=md5($password);
		$pword.=md5("marketcity");
		$mpassword=md5($pword);
	
		if($category=="userLogin")
			$sql="select * from  tbl_member where email=:username or username=:username and password=:password and delete_status=:d_status";
		else if($category=="adminLogin")
			$sql="";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':username'=>$username,':password'=>$mpassword,':d_status'=>0));
		
		$query->bindColumn("email",$xemail);
		$query->bindColumn("password",$xpassword);
		$query->bindColumn("member_code",$member_code);
		$query->bindColumn("id_member",$id_member);
		
		if($query->rowCount()==0)
			return false;
		else
		{
			while($query->fetch(PDO::FETCH_ASSOC))
			{
				if($mpassword==$xpassword)
				{
					$_SESSION['member_code']=$member_code;
					$_SESSION['member_id']=$id_member."/".$member_code;
					$_SESSION['mc_logged']=TRUE;
					
					//for coockies
					if(($remember==1)){
						
					  setcookie("member_code", $member_code, time()+60*24*60*60, "/"); // 60 days; 24 hours; 60 mins; 60secs
					  
					}else{
						setcookie("member_code", '', time()-42000, '/');
					}
					return true;
				}
				else
					return false;
			}
		}
	}
	
	public function checkExistingData($email,$phone)
	{
		$sql="select * from tbl_member where email=:email or phone=:phone and delete_status=:d_status";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':email'=>$email,':phone'=>$phone,':d_status'=>0));
		
		if($query->rowCount()>0)
			return false;
		else
			return true;
	}
	public function checkExistingEmail($email)
	{
		$sql="select * from tbl_member where email=:email delete_status=:d_status";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':email'=>$email,':d_status'=>0));
		
		if($query->rowCount()>0)
			return false;
		else
			return true;
	}
	public function checkExistingPhone($phone)
	{
		$sql="select * from tbl_member where phone=:phone delete_status=:d_status";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':phone'=>$phone,':d_status'=>0));
		
		if($query->rowCount()>0)
			return false;
		else
			return true;
	}
	
	
	public function checkUserPass($member_id,$inputCurPass)
	{		
		$sql="select * from tbl_member where id_member=:member_id and password=:inputCurPass and delete_status=:d_status";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':member_id'=>$member_id,':inputCurPass'=>$inputCurPass,':d_status'=>0));
		
		if($query->rowCount()>0)
			return false;
		else
			return true;
	}
	
	public function getCategory($type)
	{
		$sql="select * from tbl_productcat order by product_title desc";
		$query=$this->conn->prepare($sql);
		$query->execute();
		
		$query->bindColumn("id_product",$id_product);
		$query->bindColumn("product_title",$title);
		$query->bindColumn("url_title",$url);
		
		while($query->fetch(PDO::FETCH_BOTH))
		{
			if($type=="link")
				echo '<li><a href="'.$this->root.'product/'.$url.'" >'.$title.'</a></li>';
			else if($type=="select")
				echo '<option value="'.$url.'">'.$title.'</option>';
		}
	}
	
	
	public function loadLodgeName($user_number)
	{	
		
		$sql="select * from tbl_user where user_number=:user_number limit 1";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_number'=>$user_number));
		
		
		$query->bindColumn("user_lodge",$user_lodge);
		
		if($query->rowCount()==0)
			$this->output= "No Product yet. Please select another from the categories list.";
		else
		{                  
			$this->output='';
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
					$this->output =json_encode($user_lodge);
			}
				
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output =json_encode($user_lodge);
	}
	public function checkForUploadedPixM($phoneNumber)
	{	
		
		$sql="select * from tbl_pixoperation where status=:status";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':status'=>"new"));
		
		$query->bindColumn("id",$id);
		$query->bindColumn("pix",$pix);
		
			
		if($query->rowCount()==0){
			///$this->output= "";
		}
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				@updateData::checkForUploadedPixM($pix,$phoneNumber);
					
			}
				
		}
		
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			//echo $this->output;
	}
	public function updateGossip($mylodge)
	{	
		
		$sql="select * from tbl_gossip where gossip_lodge=:gossip_lodge and status=:status";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':gossip_lodge'=>$mylodge,':status'=>"new"));
		
		$query->bindColumn("gossip_id",$gossip_id);
		$query->bindColumn("gossip",$gossip);
		$query->bindColumn("gossip_owner",$gossip_owner);
		$query->bindColumn("gossip_lodge",$gossip_lodge);
		$query->bindColumn("gossip_date",$gossip_date);
			
		if($query->rowCount()==0)
			$this->output= "";
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
					$this->output .="<p><b>".$gossip_owner."</b>:  In: <b>".$gossip_lodge.":</b></br>     ".$gossip." <b>On</b> ".$gossip_date."</br></p>"; 
			}
				
		}
		@updateData::updateGossipRecord($gossip_id);
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output;
	}
	public function followcount($number)
	{	
		
		$sql="select * from tbl_follow where beenFollowed=:number";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':number'=>$number));
		
		$query->bindColumn("id_follow",$id_follow);
		$query->bindColumn("count",$count);
	
			
		if($query->rowCount()==0)
			$this->output= 0;
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
					$this->output =$count; 
			}
				
		}
					echo $this->output;
	}
	public function followcount2($number)
	{	
		
		$sql="select * from tbl_follow where beenFollowed=:number";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':number'=>$number));
		
		$query->bindColumn("id_follow",$id_follow);
		$query->bindColumn("count",$count);
	
			
		if($query->rowCount()==0)
			$count= 0;
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
					$count =$count; 
			}
				
		}
					return $count;
	}
	
	public function followUserCheck($Number)
	{	
		
		$sql="select * from tbl_follow where beenFollowed=:number";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':number'=>$Number));
		
		$query->bindColumn("id_follow",$id_follow);
		$query->bindColumn("count",$count);
	
			
		if($query->rowCount()==0)
			$this->output= 0;
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
					$this->output=1; 
			}
				
		}
					echo $this->output;
	}
	public function getIfFollowed($pname,$pPrice,$pDesc,$pin,$phone,$myName,$profileId)
	{	
		
		$sql="select * from tbl_follow where beenFollowed=:number";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':number'=>$phone));
		
		$query->bindColumn("id_follow",$id_follow);
		$query->bindColumn("count",$count);
		$query->bindColumn("follower",$follower);
			
		if($query->rowCount()==0)
			$this->output= 0;
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
					//$follower=$follower; 
					selectData::getIdFollower($pname,$pPrice,$pDesc,$pin,$phone,$myName,$profileId,$follower);
			}
				
		}
					//echo $this->output;
	}
	public function getIdFollower($pname,$pPrice,$pDesc,$pin,$phone,$myName,$profileId,$follower)
	{	
		
		$sql="select * from tbl_user where user_number=:user_number";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_number'=>$follower));
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("user_full_name",$user_full_name);
		
			
		if($query->rowCount()==0)
			$this->output= 0;
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
					//$this->output.=$follower; 
					insertData::sendChatToFollower($pname,$pPrice,$pDesc,$pin,$phone,$myName,$profileId,$follower,$user_full_name,$user_id);
			}
				
		}
					//echo $this->output;
	}
	
	
	public function loadUserProduct($per_p,$phone)
	{	
		
		$sql="select * from tbl_market order by id_m desc  ";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':per_p'=>$per_p));
		
		$query->bindColumn("id_m",$id_m);
		$query->bindColumn("p_name",$p_name);
		$query->bindColumn("p_price",$p_price);
		$query->bindColumn("p_desc",$p_desc);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("userName",$userName);
		$query->bindColumn("p_Picture",$p_Picture);	
		$query->bindColumn("userid",$userid);
		if($query->rowCount()==0)
			$result= "No Item yet";
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			 $count=selectData::followcount2($user_number);
			
			if($p_Picture=="")
			
			{
				if($user_number==$_SESSION['user_phone'])
{
				
					$result .="<b>Owned By:</b> ".$userName.":   <img src='icons/phone.png' height='20px' width='10px' style='vertical-align:middle;' />:  ".$user_number." &nbsp;&nbsp;&nbsp;<b>".$count."</b> Follower(s)<br><b>Item Name: </b> ".$p_name.":<br><b>Price</b>:    ".$p_price." <br><b>Description:</b>   ".$p_desc."  <br></a>  </br><hr>"; 
}
else{
	
					$result .=" <b>Owned By:</b> ".$userName.":  <img src='icons/phone.png' height='20px' width='10px' style='vertical-align:middle;' />:  ".$user_number."  &nbsp;&nbsp;&nbsp;;<b>".$count."</b> Follower(s)<br><b>Item Name: </b> ".$p_name.":<b><br>Price</b>:    ".$p_price." <br><b>Description:</b>   ".$p_desc."<br><a href='#' onClick='followUser(".$user_number.")';> <img src='img/follow.png' height='30px' width='70px' style='vertical-align:middle;'/></a>  <a href='#lmp' onClick='update(".$userid.")';><img src='img/chat.png' height='15px' width='20px' style='vertical-align:middle;' /></a> </br><hr>"; 
}
				}
			else{
	if($user_number==$_SESSION['user_phone'])
{
				
					@$result .="<b>Owned By:</b> ".$userName.":  <img src='icons/phone.png' height='20px' width='10px' style='vertical-align:middle;' />:  ".$user_number."  &nbsp;&nbsp;&nbsp;<b>".$count."</b> Follower(s)<br><br><b>Item Name: </b> ".$p_name.":<br><b>Price</b>:    ".$p_price." <br><b>Description:</b>   ".$p_desc."  <br></a></br><hr>"; 
}
else{
	
					@$result .="<b>Owned By:</b> ".$userName.":  <img src='icons/phone.png' height='20px' width='10px' style='vertical-align:middle;' />: ".$user_number."  &nbsp;&nbsp;&nbsp;<b>".$count."</b> Follower(s)<br> <br><b>Item Name: </b> ".$p_name.":<br><b>Price</b>:    ".$p_price." <br><b>Description:</b>   ".$p_desc."<br><a href='#' onClick='followUser(".$user_number.")';> <img src='icons/follow.png' height='28px' width='70px' style='vertical-align:middle;' /></a>  <a href='#lmp' onClick='update(".$userid.")';><img src='icons/chat.png' height='15px' width='20px' style='vertical-align:middle;' /> </a>  </br><hr>"; 
}
			}
			}
				
		}
	
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo @$result;
	}public function loadUserProduct_m()
	{	$per_p=300;
		
		$sql="select * from tbl_market order by id_m desc limit $per_p ";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':per_p'=>$per_p));
		
		$query->bindColumn("id_m",$id_m);
		$query->bindColumn("p_name",$p_name);
		$query->bindColumn("p_price",$p_price);
		$query->bindColumn("p_desc",$p_desc);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("userName",$userName);
		$query->bindColumn("p_Picture",$p_Picture);	
		$query->bindColumn("userid",$userid);
		if($query->rowCount()==0)
			$result= "No Item yet";
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			 $count=selectData::followcount2($user_number);
			
			if($p_Picture=="")
			
			{
				if($user_number==$_SESSION['user_phone'])
{
				
					$result .="<p><b>Owned By:</b> ".$userName.":   <img src='img/phone.png' height='20px' width='10px' style='vertical-align:middle;' />:  ".$user_number." &nbsp;&nbsp;&nbsp;<b>".$count."</b> Follower(s)<br><b>Item Name: </b> ".$p_name.":<br><b>Price</b>:    ".$p_price." <br><b>Description:</b>   ".$p_desc."  <br></a>  </br></p>"; 
}
else{
	
					$result .="<p> <b>Owned By:</b> ".$userName.":  <img src='img/phone.png' height='20px' width='10px' style='vertical-align:middle;' />:  ".$user_number."  &nbsp;&nbsp;&nbsp;;<b>".$count."</b> Follower(s)<br><b>Item Name: </b> ".$p_name.":<b><br>Price</b>:    ".$p_price." <br><b>Description:</b>   ".$p_desc."<br><a href='#' onClick='followUser(".$user_number.")';> <img src='img/follow.png' height='30px' width='70px' style='vertical-align:middle;'/></a>  <a href='#lmp' onClick='update(".$userid.")';><img src='img/chat.png' height='15px' width='20px' style='vertical-align:middle;' /></a> </br></p>"; 
}
				}
			else{
	if($user_number==$_SESSION['user_phone'])
{
				
					$result .="<p><b>Owned By:</b> ".$userName.":  <img src='img/phone.png' height='20px' width='10px' style='vertical-align:middle;' />:  ".$user_number."  &nbsp;&nbsp;&nbsp;<b>".$count."</b> Follower(s)<br><b>Item Name: </b> ".$p_name.":<br><b>Price</b>:    ".$p_price." <br><b>Description:</b>   ".$p_desc."  <br></a></br></p>"; 
}
else{
	
					$result .="<p><b>Owned By:</b> ".$userName.":  <img src='img/phone.png' height='20px' width='10px' style='vertical-align:middle;' />: ".$user_number."  &nbsp;&nbsp;&nbsp;<b>".$count."</b> Follower(s) <br><b>Item Name: </b> ".$p_name.":<br><b>Price</b>:    ".$p_price." <br><b>Description:</b>   ".$p_desc."<br><a href='#' onClick='followUser(".$user_number.")';> <img src='img/follow.png' height='28px' width='70px' style='vertical-align:middle;' /></a>  <a href='#lmp' onClick='update(".$userid.")';><img src='img/chat.png' height='15px' width='20px' style='vertical-align:middle;' /> </a>  </br></p>"; 
}
			}
			}
				
		}
	
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $result;
	}
	public function loadSearchProduct($per_p,$searchvalue,$phone)
	{	
		
		$sql="select * from tbl_market where p_name like :searchvalue order by id_m desc ";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':searchvalue'=>"%".$searchvalue."%"));
	
		
		
		$query->bindColumn("id_m",$id_m);
		$query->bindColumn("p_name",$p_name);
		$query->bindColumn("p_price",$p_price);
		$query->bindColumn("p_desc",$p_desc);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("userName",$userName);
		$query->bindColumn("p_Picture",$p_Picture);	
		$query->bindColumn("userid",$userid);
		if($query->rowCount()==0)
			$this->output= "No Item Found!";
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			 $count=selectData::followcount2($user_number);
			
			if($p_Picture=="")
			
			{
				if($user_number==$phone)
{
				
					$this->output .="<h5><p>Owned By: <b>".$userName.":</b>   <img src='img/phone.png' height='20px' width='10px' style='vertical-align:middle;' />:  ".$user_number." &nbsp;&nbsp;&nbsp;<b>".$count."</b> Follower(s)<br><b>Item Name: </b> ".$p_name.":<br><b>Price</b>:    ".$p_price." <br><b>Description:</b>   ".$p_desc."  <br></a>  </br></p></h5>"; 
}
else{
	
					$this->output .="<h5><p>Owned By: <b>".$userName.":</b>   <img src='img/phone.png' height='20px' width='10px' style='vertical-align:middle;' />:  ".$user_number."  &nbsp;&nbsp;&nbsp;<b>".$count."</b> Follower(s)<br><b>Item Name: </b> ".$p_name.":<b><br>Price</b>:    ".$p_price." <br><b>Description:</b>   ".$p_desc."<br><a href='#' onClick='followUser(".$user_number.")';> <img src='img/follow.png' height='30px' width='70px' style='vertical-align:middle;'/></a>  <a href='#lmp' onClick='update(".$userid.")';><img src='img/chat.png' height='15px' width='20px' style='vertical-align:middle;' /></a></br></p></h5>"; 
}
				}
			else{
	if($user_number==$phone)
{
				
					$this->output .="<h5><p>Owned By: <b>".$userName.":</b>  <img src='img/phone.png' height='20px' width='10px' style='vertical-align:middle;' />:  ".$user_number."  &nbsp;&nbsp;&nbsp;<b>".$count."</b> Follower(s)<br><img style='border-radius:20px;' src='uploads/".$p_Picture."' height='50px' width='60px'> <br><b>Item Name: </b> ".$p_name.":<br><b>Price</b>:    ".$p_price." <br><b>Description:</b>   ".$p_desc."  <br></a> </br></p>"; 
}
else{
	
					$this->output .="<h5><p>Owned By: <b>".$userName.":</b>  <img src='img/phone.png' height='20px' width='10px' style='vertical-align:middle;' />: ".$user_number."  &nbsp;&nbsp;&nbsp;<b>".$count."</b> Follower(s)<br><img style='border-radius:20px;' src='uploads/".$p_Picture."' height='50px' width='60px'> <br><b>Item Name: </b> ".$p_name.":<br><b>Price</b>:    ".$p_price." <br><b>Description:</b>   ".$p_desc."<br><a href='#' onClick='followUser(".$user_number.")';> <img src='img/follow.png' height='28px' width='70px' style='vertical-align:middle;' /></a>  <a href='#lmp' onClick='update(".$userid.")';><img src='img/chat.png' height='15px' width='20px' style='vertical-align:middle;' /> </a> </br></p></h5>"; 
}
			}
			}
				
		}
	
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output;
	}
	public function myShop($number)
	{	
		
		$sql="select * from tbl_market where user_number=:number";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':number'=>$number));
		
		$query->bindColumn("id_m",$id_m);
		$query->bindColumn("p_name",$p_name);
		$query->bindColumn("p_price",$p_price);
		$query->bindColumn("p_desc",$p_desc);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("userName",$userName);
		$query->bindColumn("p_Picture",$p_Picture);	
		$query->bindColumn("userid",$userid);
		$query->bindColumn("pin",$pin);
		if($query->rowCount()==0)
			$this->output= "No Item yet";
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			
			$this->output .="<b>Item Name: </b> ".$p_name.":<br><b>Price</b>:    ".$p_price." <br><b>Description:</b>   ".$p_desc."<br><a href='#' onClick='editUserProduct(".$pin.")';> <img src='icons/100-coffee.png' height='15px' width='20px' style='vertical-align:middle;' />Delete Item</a>   </br><hr>"; 
			
			}
		}
	
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output;
	}
	public function myShopCollect($pin,$phone)
	{	
		
		$sql="select * from tbl_market where user_number=:number And pin=:pin";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':number'=>$phone,':pin'=>$pin));
		
		$query->bindColumn("id_m",$id_m);
		$query->bindColumn("p_name",$p_name);
		$query->bindColumn("p_price",$p_price);
		$query->bindColumn("p_desc",$p_desc);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("userName",$userName);
		$query->bindColumn("p_Picture",$p_Picture);	
		$query->bindColumn("userid",$userid);
		$query->bindColumn("pin",$pin);
		if($query->rowCount()==0)
			$this->output= "No Item yet";
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			
			$this->output =$p_name.'*'.$p_price.'*'.$p_Picture.'*'.$pin; 
			
			}
		}
	
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output;
	}
	public function loaddateline($per_p)
	{	
		
		$sql="select * from tbl_market order by id_m desc limit $per_p ";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':per_p'=>$per_p));
		
		$query->bindColumn("id_m",$id_m);
		$query->bindColumn("date",$date);
	;
			
		if($query->rowCount()==0)
			$this->output= "";
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
					$this->output ="<p><h6>".$date."</br><a href='#' onClick='loadMore()';>Load More Items</a></h6></p>"; 
			}
				
		}
	
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output;
	}
	/*public function loadUserProduct($myPhone)
	{	
		
		$sql="select * from tbl_market where user_number=:user_number";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_number'=>$myPhone));
		
		$query->bindColumn("id_m",$id_m);
		$query->bindColumn("p_name",$p_name);
		$query->bindColumn("p_price",$p_price);
		$query->bindColumn("p_desc",$p_desc);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("userName",$userName);
			
		if($query->rowCount()==0)
			$this->output= "";
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
					$this->output .="<p><b>".$userName.":</b> { ".$user_number." } <br>Product Picture <br><b>Product Name: </b> ".$p_name.":<b>Price</b>:    ".$p_price." <br><b>Description:</b>   ".$p_desc." | <a href='#'> Share </a>| View |</br></p>"; 
			}
				
		}
	
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output;
	}*/
	public function loginPhone($phone,$password)
	{	
		updateData::updateStatusLine($phone);
		
		$sql="select * from tbl_user where user_number=:user_number and user_password=:user_password";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_number'=>$phone,':user_password'=>$password));
		
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("user_full_name",$user_full_name);
		$query->bindColumn("user_school",$user_school);
		$query->bindColumn("user_lodge",$user_lodge);
		$query->bindColumn("user_gender",$user_gender);
		$query->bindColumn("picture",$picture);
		$query->bindColumn("dept",$dept);
		if($query->rowCount()==0)
			$this->output= 0;
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	   
			    $_SESSION['user_full_name']=$user_full_name;
			    $_SESSION['user_school']=$user_school;
				$_SESSION['user_lodge']=$user_lodge;
				$_SESSION['dept']=$dept;
				$_SESSION['user_phone']=$phone;
				$_SESSION['picture']=$picture;
					$this->output =$user_id.'*'.$user_full_name.'*'.$user_school.'*'.$user_lodge.'*'.$user_gender.'*'.$picture.'*'.$dept;
			}
				
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output;
	}
	public function checkPhone($Phone)
	{	
		
		$sql="select * from tbl_user where user_number=:user_number";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_number'=>$Phone));
		
		
		$query->bindColumn("user_id",$user_id);
		
		
		if($query->rowCount()==0)
			$this->output= 0;
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				$this->output =1;
			}
				
		}
			echo $this->output;
	}
	public function loadAlodge($school)
	{	
		
		$sql="select * from tbl_lodge where school_id=:school_id order by lodge_name ASC";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':school_id'=>$school));
		
		
		$query->bindColumn("lodge_name",$lodge_name);
		
		
		if($query->rowCount()==0)
			$this->output= "No Lodge found";
		else
		{           
		$this->output =" <select name='lodge'  id='lodge' onchange='c()'>";
      
     
    
          
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			    
				$this->output .="<option>".$lodge_name."</option>";
			}
				$this->output .=" </select>";
		}
			echo $this->output;
	}
	public function viewProfile($profileUserFullname,$profileUserPhone)
	{	
		
		$sql="select * from tbl_user where user_number=:user_number  limit 1";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_number'=>$profileUserPhone));
		
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("user_full_name",$user_full_name);
		$query->bindColumn("user_school",$user_school);
		$query->bindColumn("user_lodge",$user_lodge);
		$query->bindColumn("user_gender",$user_gender);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("College",$College);
		$query->bindColumn("dept",$dept);
		$query->bindColumn("picture",$picture);
		$query->bindColumn("lineStatus",$lineStatus);
		if($query->rowCount()==0)
			$this->output= "No User Selected.";
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			$pix="<img style='border-radius:5px;' src='userpix/".$picture."' height='100px' width='100px'> ";
				
					$this->output =json_encode($user_id.'*'.$user_full_name.'*'.$user_school.'*'.$user_lodge.'*'.$user_gender.'*'.$user_number.'*'.$College.'*'.$dept.'*'.$pix.'*'.$lineStatus);
			}
				
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output =json_encode($user_id.'*'.$user_full_name.'*'.$user_school.'*'.$user_lodge.'*'.$user_gender.'*'.$user_number.'*'.$College.'*'.$dept.'*'.$pix.'*'.$lineStatus);
	}
	public function LoadUser($id_user)
	{	

		$sql="select * from tbl_user where user_id=:user_id limit 1";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_id'=>$id_user));
		
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("user_full_name",$user_full_name);
		$query->bindColumn("user_school",$user_school);
		$query->bindColumn("user_lodge",$user_lodge);
		$query->bindColumn("user_gender",$user_gender);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("status",$status);
		$query->bindColumn("picture",$picture);
		if($query->rowCount()==0)
			$this->output= "No user Selected ";
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
				if($picture==""){
					$pict='<img style="border-radius:10px;"  src="userpix/patient.png" height="50px" width="50px" >';
				}
				else{
				$pict='<img style="border-radius:10px;"  src="userpix/'.$picture.'" height="50px" width="50px" >';
				
					$this->output =json_encode($user_id.'*'.$user_full_name.'*'.$user_school.'*'.$user_lodge.'*'.$user_gender.'*'.$user_number.'*'.$status.'*'.$pict);
				}
			}
				
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output =json_encode($user_id.'*'.$user_full_name.'*'.$user_school.'*'.$user_lodge.'*'.$user_gender.'*'.$user_number.'*'.$status.'*'.$pict);
	}
	public function updateChat($Sender,$reciever)
	{	

		$sql="select * from tbl_chat where sender_Number=:sender_Number and reciever_Number=:reciever_Number or sender_Number=:reciever_Number and reciever_Number=:sender_Number";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':sender_Number'=>$Sender,':reciever_Number'=>$reciever));
		
		
		$query->bindColumn("chat_id",$chat_id);
		$query->bindColumn("name",$name);
		$query->bindColumn("message",$message);
		$query->bindColumn("dateOfchat",$dateOfchat);
		$query->bindColumn("sender_Number",$sender_Number);
		$query->bindColumn("reciever_Number",$reciever_Number);
		if($query->rowCount()==0)
			$this->output= "<p>No Chat yet.</p>";
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
			
				if($sender_Number==$Sender)
				{
					
				 $this->output .="<div class='triangle-right  right'>".htmlspecialchars($message)."    <h5><hr>".$dateOfchat."</h5></div>";  
				 // $this->output .="<div id='chat1'><h6>".$message."  |  ".$dateOfchat."</h6></div>"; 
					
				
				}
				else
				{    				 $this->output .="<div class='triangle-right  left'>".htmlspecialchars($message)." <h5><hr> ".$dateOfchat."</h5></div>";  

					//$this->output .="<div  id='chat2'><h6>".$dateOfchat."|: ".$message."</h6></div>"; 
					
				}
					//$this->output .=$chat_id.'*'.$name.'*'.$message.'*'.$dateOfchat.'*'.$sender_Number.'*'.$reciever_Number;
			}
			
				            
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output;
	}
	public function updateChatBySeconds2($phone,$myphone,$recievername,$myname)
	{	
/*	$sql="select * from tbl_chat where reciever_Number=:reciever_Number and recievername=:recievername and name=:myname and status=:status limit 1";*/
		$sql="select * from tbl_chat where  recievername=:recievername and name=:myname and status=:status or recievername=:myname and name=:recievername and status=:status limit 1";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':status'=>"new",':recievername'=>$recievername,':myname'=>$myname));
		
		
		$query->bindColumn("chat_id",$chat_id);
		$query->bindColumn("name",$name);
		$query->bindColumn("message",$message);
		$query->bindColumn("dateOfchat",$dateOfchat);
		$query->bindColumn("sender_Number",$sender_Number);
		$query->bindColumn("reciever_Number",$reciever_Number);
		if($query->rowCount()==0)
			{
			}
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			
			   $this->output =$name."</b>:  ".$message."  |  ".$dateOfchat."</p>"; 
			 
			 
				//$this->output .="<p><b>".$name."</b>: message ".$message."  date ".$dateOfchat."</p>"; 
				//@updateData::updateChatRecord($chat_id);
				
			}
	            
		}
		
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output;
	}
	public function loaddatelineV($per_pV,$type)
	{	
		
		$sql="select * from tbl_vacant where type=:type  order by id desc limit $per_pV ";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':type'=>$type));
		
		$query->bindColumn("id",$id);
		$query->bindColumn("date",$date);
	;
			
		if($query->rowCount()==0)
			$this->output= "";
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
					$this->output ="<p><h6>".$date."</br><a href='#' onClick='loadMoreV()';>Load More Items</a></h6></p>"; 
			}
				
		}
	
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output;
	}
	
	
	public function displayVacant()
	{	
          $per_pV=3;
		  
		$sql="select * from tbl_vacant where type!=:type order by id desc limit $per_pV";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':type'=>""));
		
		
		$query->bindColumn("qst1",$qst1);
		$query->bindColumn("qst2",$qst2);
		$query->bindColumn("qst3",$qst3);
		$query->bindColumn("qst4",$qst4);
		$query->bindColumn("number",$number);
		$query->bindColumn("name",$name);
		if($query->rowCount()==0)
			{
				@$result="Nothing Yet";
			}
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			
			   @$result .="<p><b>Name:</b>".$name." <b>Number:</b> ".$number."<br><b>REQUEST: </b>".$qst1."<br><b>Gender:</b> ".$qst3."<br><b> At: </b>".$qst2."<br><b>Level: </b> ".$qst4." <hr>
			   </p>"; 

			 
				//$this->output .="<p><b>".$name."</b>: message ".$message."  date ".$dateOfchat."</p>"; 
				//@updateData::updateChatRecord($chat_id);
				
			}
	            
		}
		
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $result;
	}
	public function displayVacantMore()
	{	
          $per_pV=300;
		  
		$sql="select * from tbl_vacant where type!=:type order by id desc limit $per_pV";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':type'=>""));
		
		
		$query->bindColumn("qst1",$qst1);
		$query->bindColumn("qst2",$qst2);
		$query->bindColumn("qst3",$qst3);
		$query->bindColumn("qst4",$qst4);
		$query->bindColumn("number",$number);
		$query->bindColumn("name",$name);
		if($query->rowCount()==0)
			{
				$result="Nothing Yet";
			}
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			
			   $result .="<p><b>Name:</b>".$name." <b>Number:</b> ".$number."<br><b>REQUEST: </b>".$qst1."<br><b>Gender:</b> ".$qst3."<br><b> At: </b>".$qst2."<br><b>Level: </b> ".$qst4." <hr>
			   </p>"; 

			 
				//$this->output .="<p><b>".$name."</b>: message ".$message."  date ".$dateOfchat."</p>"; 
				//@updateData::updateChatRecord($chat_id);
				
			}
	            
		}
		
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $result;
	}
	public function updateChatByUser($user_number,$user_full_name,$phone)
	{	
$user_number=$_SESSION['user_phone'];
/*	$sql="select * from tbl_chat where reciever_Number=:reciever_Number and recievername=:recievername and name=:myname and status=:status limit 1";*/




		$sql="select * from tbl_chat where reciever_Number=:user_number and sender_Number=:sender_Number or  reciever_Number=:sender_Number and sender_Number=:user_number order by chat_id asc";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_number'=>$user_number,':sender_Number'=>$phone));
		
		
		$query->bindColumn("chat_id",$chat_id);
		$query->bindColumn("name",$name);
		$query->bindColumn("message",$message);
		$query->bindColumn("dateOfchat",$dateOfchat);
		$query->bindColumn("sender_Number",$sender_Number);
		$query->bindColumn("reciever_Number",$reciever_Number);
		$query->bindColumn("status",$status);
		if($query->rowCount()==0)
			{
				$result="";
			}
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			
			if($status=="new")
			{
				
				$result= "<font color='#0000CC'>".$this->ShortenText2($message,13).":       Last seen on ".$this->ShortenText2($dateOfchat,15)."</font>"; 

			}else
			{
				$result= $this->ShortenText2($message,13).":       Last seen on ".$this->ShortenText2($dateOfchat,15); 

			}
			 
				//$this->output .="<p><b>".$name."</b>: message ".$message."  date ".$dateOfchat."</p>"; 
				//@updateData::updateChatRecord($chat_id);
				
			}
	           
		}
		 return $result;
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			
	}
	public function updateChatBySeconds($phone,$myphone,$recievername,$myname)
	{	
		//$myphone=$_SESSION['user_phone'];
/*	$sql="select * from tbl_chat where reciever_Number=:reciever_Number and recievername=:recievername and name=:myname and status=:status limit 1";*/
        $status="ONLINE";
		updateData::updateStatusLineN($phone,$status);
		$sql="select * from tbl_chat where  recievername=:myname and name=:recievername and status=:status limit 1";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':status'=>"new",':recievername'=>$recievername,':myname'=>$myname));
		
		
		$query->bindColumn("chat_id",$chat_id);
		$query->bindColumn("name",$name);
		$query->bindColumn("message",$message);
		$query->bindColumn("dateOfchat",$dateOfchat);
		$query->bindColumn("sender_Number",$sender_Number);
		$query->bindColumn("reciever_Number",$reciever_Number);
		if($query->rowCount()==0)
			{
				$this->output=0;
			}
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			
			  if($myphone==$reciever_Number){
				if($sender_Number==$myphone)
				{
					
				 $this->output .="<div class='triangle-right  right'>".htmlspecialchars($message)."    <h5><hr>".$dateOfchat."</h5></div>";  
				 // $this->output .="<div id='chat1'><h6>".$message."  |  ".$dateOfchat."</h6></div>"; 
					
				
				}
				else
				{    				 $this->output .="<div class='triangle-right  left'>".htmlspecialchars($message)." <h5><hr> ".$dateOfchat."</h5></div>";  

					//$this->output .="<div id='chat2'><h5>".$dateOfchat."|: ".$message."</h5></div>"; 
					
				}
			  }
			  else{
				  $this->output .="";
			  }
				//$this->output .="<p><b>".$name."</b>: message ".$message."  date ".$dateOfchat."</p>"; 
				@updateData::updateChatRecord($chat_id);
				
			}
	            
		}
		
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
		 $status="OFFLINE";
		 updateData::updateStatusLineN($phone,$status);
			echo $this->output;
	}
	public function updateChatGroupBySeconds($lodgeGroupId,$senderNumber)
	{	
		//$myphone=$_SESSION['user_phone'];
/*	$sql="select * from tbl_chat where reciever_Number=:reciever_Number and recievername=:recievername and name=:myname and status=:status limit 1";
        $status="ONLINE";
		updateData::updateStatusLineN($phone,$status);*/
		$sql="select * from tbl_groupchat where  lodgeName=:lodgeName";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':lodgeName'=>$lodgeGroupId));
		
		
		$query->bindColumn("tbl_id",$tbl_id);
		$query->bindColumn("userName",$userName);
		$query->bindColumn("phone",$phone);
		$query->bindColumn("dateOfChat",$dateOfChat);
		$query->bindColumn("chat",$chat);
		if($query->rowCount()==0)
			{
				$this->output=0;
			}
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			
			  if($phone==$senderNumber){
				  
				    
			
				//$this->output .="<p><b>".$name."</b>: message ".$message."  date ".$dateOfchat."</p>"; 
				//@updateData::updateChatRecord($chat_id);
			  }
			  else{
				  $this->output ="<div class='triangle-right  left'><u>".$userName."</u><br>  ".htmlspecialchars($chat)."  <h5>".$dateOfChat."</h5></div>"; 
			  }
			}
	            
		}
		
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
		// $status="OFFLINE";
		 //updateData::updateStatusLineN($phone,$status);
			echo $this->output;
	}
public function LodgeMate($lodge,$phone)
	{	
		
		
		$sql="select * from tbl_user where user_lodge=:user_lodge and user_number!=:phone";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_lodge'=>$lodge,':phone'=>$phone));
		
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("user_full_name",$user_full_name);
		$query->bindColumn("user_school",$user_school);
		$query->bindColumn("user_lodge",$user_lodge);
		$query->bindColumn("user_gender",$user_gender);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("status",$status);
		$query->bindColumn("picture",$picture);
		$query->bindColumn("dept",$dept);
		if($query->rowCount()==0)
			$result= "No User Yet.";
		else
		{                  
		
		
          /* $this->output='<div data-role="popup" id="popupMenu" data-theme="b">
					<ul data-role="listview" data-inset="true" style="min-width:210px;">';*/
		while($query->fetch(PDO::FETCH_BOTH))
		  {	
			$latest=selectData::updateChatByUser($user_number,$user_full_name,$phone);
			$follow=selectData::followcount2($user_number);
			
			
		if($picture=="")
		{
			@$result.='<div data-role="collapsible" data-collapsed-icon="carat-d" data-expanded-icon="carat-u">
    <h4><img style="border-radius:5px;"  src="userpix/patient.png" height="30px" width="30px" >&nbsp; &nbsp;&nbsp; &nbsp;'.strtoupper($user_full_name).'</h4>
    <ul data-role="listview" data-inset="false">
       <li>Department:&nbsp;'.$dept.'  </li>
        <li>Followers:&nbsp;<font color="#FF0000">'.$follow.'</font>&nbsp;Mobile Number: &nbsp;<font color="#FF0000">'.$user_number.'</font></li>
        <li> <a href="#lmp" onClick="update('.$user_id.');">Chat Now >> </a> </li>
        
    </ul>
</div>';
				/*$result .='<table  >
  <tr>
    <td rowspan="3"> <a href="javascript:void(0)" onClick="javascript:chatWith('.$user_full_name.')"><img style="border-radius:5px;"  src="userpix/patient.png" height="20px" width="20px" ></a></td>
    <td>   &nbsp; &nbsp;'.strtoupper($user_full_name)."&nbsp; &nbsp;&nbsp; &nbsp;<font color='#006699'> ".$follow." followers</font>".'</td>
  </tr>

</table><hr>';*/
		}
		else{
			@$result.='<div data-role="collapsible" data-collapsed-icon="carat-d" data-expanded-icon="carat-u">
    <h4><img style="border-radius:5px;" src="userpix/'.$picture.'" height="30px" width="30px" >&nbsp; &nbsp;&nbsp; &nbsp;'.strtoupper($user_full_name).'</h4>
    <ul data-role="listview" data-inset="false">
	   <li>Department:&nbsp;'.$dept.'  </li>
        <li>Followers:&nbsp;<font color="#FF0000">'.$follow.'</font>&nbsp;Mobile Number: &nbsp;<font color="#FF0000">'.$user_number.'</font></li>
        <li><a href="#lmp" onClick="update('.$user_id.');">Chat Now >> </a> </li>
     
        
    </ul>
</div>';
		/*@$result .='<table  >
  <tr>
    <td rowspan="3"><a href="javascript:void(0)" onClick="javascript:chatWith(dshvbhjsbv)"><img style="border-radius:5px;"  src="userpix/'.$picture.'" height="30px" width="30px" ></td>
    <td>   &nbsp; &nbsp;'.strtoupper($user_full_name)."&nbsp; &nbsp;&nbsp; &nbsp;<font color='#006699'> ".$follow." followers</font>".'</a></td>
  </tr>

</table><hr>';*/
		}
		
			}
				
		}
		
			return $result;
	}
	public function loadDeptMate($profileDept,$myphone,$domain_school)
	{	
	
	  
		$sql="select * from tbl_user where dept=:dept and user_number!=:phone and user_school=:school";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':dept'=>$profileDept,':phone'=>$myphone,':school'=>$domain_school));
		
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("user_full_name",$user_full_name);
		$query->bindColumn("user_school",$user_school);
		$query->bindColumn("user_lodge",$user_lodge);
		$query->bindColumn("user_gender",$user_gender);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("status",$status);
		$query->bindColumn("picture",$picture);
		if($query->rowCount()==0)
			$this->output= "No User Yet.";
		else
		{                  
		$ret="";
		
          /* $this->output='<div data-role="popup" id="popupMenu" data-theme="b">
					<ul data-role="listview" data-inset="true" style="min-width:210px;">';*/
		while($query->fetch(PDO::FETCH_BOTH))
		  {	
			$latest=selectData::updateChatByUser($user_number,$user_full_name,$myphone);
			$follow=selectData::followcount2($user_number);
			
			
		if($picture=="")
		{
				$this->output.='<div data-role="collapsible" data-collapsed-icon="carat-d" data-expanded-icon="carat-u">
    <h4><img style="border-radius:5px;"  src="userpix/patient.png" height="30px" width="30px" >&nbsp; &nbsp;&nbsp; &nbsp;'.strtoupper($user_full_name).'</h4>
    <ul data-role="listview" data-inset="false">
       <li>Lodge/Hostel:&nbsp;'.$user_lodge.'  </li>
        <li>Followers:<font color="#FF0000">'.$follow.'</font>&nbsp;&nbsp;Mobile Number: &nbsp;<font color="#FF0000">'.$user_number.'</font></li>
        <li> <a href="#lmp" onClick="update('.$user_id.');">Chat Now >> </a> </li>
        
    </ul>
</div>';
		}
		else{
		
		$this->output.='<div data-role="collapsible" data-collapsed-icon="carat-d" data-expanded-icon="carat-u">
    <h4><img style="border-radius:5px;" src="userpix/'.$picture.'" height="30px" width="30px" >&nbsp; &nbsp;&nbsp; &nbsp;'.strtoupper($user_full_name).'</h4>
    <ul data-role="listview" data-inset="false">
       <li>Lodge/Hostel:&nbsp;'.$user_lodge.'  </li>
        <li>Followers:<font color="#FF0000">'.$follow.'</font>&nbsp;&nbsp;Mobile Number: &nbsp;<font color="#FF0000">'.$user_number.'</font></li>
        <li> <a href="#lmp" onClick="update('.$user_id.');">Chat Now >> </a> </li>
        
    </ul>
</div>';
		}
		
			}
				
		}
		
			return $this->output;
	}
	
	public function otherSchooldepartment($profileDept,$myphone,$domain_school)
	{	
	
	  
		$sql="select * from tbl_user where dept=:dept and user_number!=:phone and user_school!=:school";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':dept'=>$profileDept,':phone'=>$myphone,':school'=>$domain_school));
		
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("user_full_name",$user_full_name);
		$query->bindColumn("user_school",$user_school);
		$query->bindColumn("user_lodge",$user_lodge);
		$query->bindColumn("user_gender",$user_gender);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("status",$status);
		$query->bindColumn("picture",$picture);
		if($query->rowCount()==0)
			$this->output= "No User Yet.";
		else
		{                  
		$ret="";
		
          /* $this->output='<div data-role="popup" id="popupMenu" data-theme="b">
					<ul data-role="listview" data-inset="true" style="min-width:210px;">';*/
		while($query->fetch(PDO::FETCH_BOTH))
		  {	
			$latest=selectData::updateChatByUser($user_number,$user_full_name,$myphone);
			$follow=selectData::followcount2($user_number);
			
			
		if($picture=="")
		{
				@$t.='<div data-role="collapsible" data-collapsed-icon="carat-d" data-expanded-icon="carat-u">
    <h4><img style="border-radius:5px;"  src="userpix/patient.png" height="30px" width="30px" >&nbsp; &nbsp;&nbsp; &nbsp;'.strtoupper($user_full_name).'</h4>
    <ul data-role="listview" data-inset="false">
       <li>School:&nbsp;'.$user_school.'  </li>
        <li>Followers:<font color="#FF0000">'.$follow.'</font>&nbsp;&nbsp;Mobile Number: &nbsp;<font color="#FF0000">'.$user_number.'</font></li>
        <li> <a href="#lmp" onClick="update('.$user_id.');">Chat Now >> </a> </li>
        
    </ul>
</div>';
		}
		else{
		
		@$t.='<div data-role="collapsible" data-collapsed-icon="carat-d" data-expanded-icon="carat-u">
    <h4><img style="border-radius:5px;" src="userpix/'.$picture.'" height="30px" width="30px" >&nbsp; &nbsp;&nbsp; &nbsp;'.strtoupper($user_full_name).'</h4>
    <ul data-role="listview" data-inset="false">
       <li>School:&nbsp;'.$user_school.'  </li>
        <li>Followers:<font color="#FF0000">'.$follow.'</font>&nbsp;&nbsp;Mobile Number: &nbsp;<font color="#FF0000">'.$user_number.'</font></li>
        <li> <a href="#lmp" onClick="update('.$user_id.');">Chat Now >> </a> </li>
        
    </ul>
</div>';
		}
		
			}
				
		}
		
			return $t;
	}
	
	public function recentChatlist($phone)
	{	
		
		$this->output=array();
		$sql="select distinct(reciever_Number) from tbl_chat where sender_Number=:number";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':number'=>$phone));
		
		$query->bindColumn("reciever_Number",$sender_Number);/*
		$query->bindColumn("reciever_Number",$reciever_Number);*/
	
			
		if($query->rowCount()==0){
			//$this->output="no chat yet";
		}else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				 if($sender_Number==$phone)
				 {
					 //$this->output .=selectData::recenChat($sender_Number,$sender_Number);
				 }
			   else
			   {
					$this->output[$sender_Number] =selectData::recenChat($sender_Number);
					//$this->output .=$sender_Number."*".$reciever_Number; 
			   }
			}
				
		}
		
		
		/////////////////////////////////////////////////////////////////////////////////////////////////////////
		$sql="select distinct(sender_Number) from tbl_chat where reciever_Number=:number ";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':number'=>$phone));
		
		$query->bindColumn("sender_Number",$sender_Number);/*
		$query->bindColumn("reciever_Number",$reciever_Number);*/
	
			
		if($query->rowCount()==0){
			//$this->output="no chat yet";
		}else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				 if($sender_Number==$phone)
				 {
					 //$this->output .=selectData::recenChat($sender_Number,$sender_Number);
				 }
				   else
				   {
					$this->output[$sender_Number] =selectData::recenChat($sender_Number);
					//$this->output .=$sender_Number."*".$reciever_Number; 
				   }
			}
				
		}
		
		
		
		/////////////////////////////////////////////////////////////////////////////////////////////////////////
			foreach($this->output as $recent_chat){
					echo $recent_chat;
			}
	}
	
	
	
	
	
	public function recenChat($sender_Number)
	{	

		 $this->output2='';
		$sql="select *   from tbl_user where user_number=:user_number ";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_number'=>$sender_Number));
		
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("user_full_name",$user_full_name);
		$query->bindColumn("user_school",$user_school);
		$query->bindColumn("user_lodge",$user_lodge);
		$query->bindColumn("user_gender",$user_gender);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("status",$status);
		$query->bindColumn("picture",$picture);
		if($query->rowCount()==0)
			$this->output= "No User Yet.";
		else
		{                  
		
		
          /* $this->output='<div data-role="popup" id="popupMenu" data-theme="b">
					<ul data-role="listview" data-inset="true" style="min-width:210px;">';*/
		while($query->fetch(PDO::FETCH_BOTH))
		  {	
			$latest=selectData::updateChatByUser($user_number,$user_full_name,$sender_Number);
			$follow=selectData::followcount2($user_number);
			
			
		if($picture=="")
		{
				$this->output2 .='<p><table  >
  <tr>
    <td rowspan="3"><img style="border-radius:10px;"  src="userpix/patient.png" height="40px" width="50px" ></td>
    <td>   &nbsp; &nbsp;<a href="#lmp" onClick="update('.$user_id.');">'.strtoupper($user_full_name).'</a></td>
  </tr>
  <tr>
    <td> '.$latest.'</td>
  </tr>
</table></p><hr>';
		}
		else{
		
		$this->output2 .='<p><table  >
  <tr>
    <td rowspan="3"><img style="border-radius:10px;"  src="userpix/'.$picture.'" height="40px" width="50px" ></td>
    <td>   &nbsp; &nbsp;<a href="#lmp" onClick="update('.$user_id.');">'.strtoupper($user_full_name).'</a></td>
  </tr>
  <tr>
    <td> '.$latest.'</td>
  </tr>
</table></p><hr>';
		
		
		
		}
		
			}
				
		}
		
			return $this->output2;
	}
	public function loadAlluser()
	{	
		$myPhone=$_SESSION['user_phone'];
		$sql="select * from tbl_user where  user_number!=:phone order by user_id desc limit 3";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':phone'=>$myPhone));
		
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("user_full_name",$user_full_name);
		$query->bindColumn("user_school",$user_school);
		$query->bindColumn("user_lodge",$user_lodge);
		$query->bindColumn("user_gender",$user_gender);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("picture",$picture);
		$query->bindColumn("status",$status);
		if($query->rowCount()==0)
			$result= "No User Found";
		else
		{                  

				while($query->fetch(PDO::FETCH_BOTH))
			{	
			$latest=selectData::updateChatByUser($user_number,$user_full_name,$myPhone);
			$follow=selectData::followcount2($user_number);
			
			/*'<div id="tryuser"> <ul data-role="listview"  data-inset="true"> 
		<a href="#lmp" ><img src="icons/77-ekg.png" /><input type="button" id="" onClick="update('.$user_id.');" name="user_full_name" value="['.$user_full_name.']'.'" /></a>: '.$status.'</hr><br><div id="latestChat"></div>';*/
		if($picture=="")
		{
				@$result .='<p><table  >
  <tr>
    <td rowspan="3"><a href="#lmp" onClick="update('.$user_id.');"><img style="border-radius:10px;"  src="userpix/patient.png" height="60px" width="70px" ></a></td>
    <td>   &nbsp; &nbsp;'.strtoupper($user_full_name)."&nbsp; &nbsp;&nbsp; &nbsp;<font color='#006699'> ".$follow." followers</font>".'<br><h4>&nbsp; &nbsp;Status: '.$status.'</h4></td>
  </tr>
  <tr>
    <td><img style="border-radius:10px;"  src="img/arrow1.png" height="10px" width="10px" > &nbsp; '.$latest.'</td>
  </tr>
</table></p><hr>';
		}
		else{
		
		@$result .='<p><table  >
  <tr>
    <td rowspan="3"><a href="#lmp" onClick="update('.$user_id.');"><img style="border-radius:10px;"  src="userpix/'.$picture.'" height="60px" width="70px" ></a></td>
    <td>   &nbsp; &nbsp;'.strtoupper($user_full_name)."&nbsp; &nbsp;&nbsp; &nbsp;<font color='#006699'> ".$follow." followers</font>".'<br><h4>&nbsp; &nbsp;Status: '.$status.'</h4></td>
  </tr>
  <tr>
    <td><img style="border-radius:10px;"  src="img/arrow1.png" height="10px" width="10px" > &nbsp;'.$latest.'</td>
  </tr>
</table></p><hr>';
		}
					/*$this->output .='
					<li><img style="border-radius:20px;"  src="userpix/'.$picture.'" height="50px" width="60px" ><a href="#lmp" onClick="update('.$user_id.');">'.$user_full_name.': '.$status.'</a></li>';*/
			}
				//$this->output .=' </ul></div>';
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $result;
	}
	public function searchA($sechA,$phone)
	{	
		
		$sql="select * from tbl_user where user_full_name like :searchvalue and  user_number!=:phone";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':phone'=>$phone,':searchvalue'=>"%".$sechA."%"));
		
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("user_full_name",$user_full_name);
		$query->bindColumn("user_school",$user_school);
		$query->bindColumn("user_lodge",$user_lodge);
		$query->bindColumn("user_gender",$user_gender);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("picture",$picture);
		$query->bindColumn("status",$status);
		$query->bindColumn("dept",$dept);
		if($query->rowCount()==0)
			$this->output= "No User Found";
		else
		{                  

				while($query->fetch(PDO::FETCH_BOTH))
			{	
			$latest=selectData::updateChatByUser($user_number,$user_full_name,$phone);
			$follow=selectData::followcount2($user_number);
			
			/*'<div id="tryuser"> <ul data-role="listview"  data-inset="true"> 
		<a href="#lmp" ><img src="icons/77-ekg.png" /><input type="button" id="" onClick="update('.$user_id.');" name="user_full_name" value="['.$user_full_name.']'.'" /></a>: '.$status.'</hr><br><div id="latestChat"></div>';*/
		if($picture=="")
		{
				$this->output .='<table  >
  <tr>
    <td rowspan="3"><img style="border-radius:10px;"  src="userpix/patient.png" height="60px" width="70px" ></a></td>
    <td>  <a href="#lmp" onClick="update('.$user_id.');"> '.strtoupper($user_full_name)." </a><br><b>School:</b> ".$user_school."  ".'<br><b>Department:</b> '.$dept.'</td>
  </tr>
  <tr>
    <td><img  src="icons/04-squiggle.png"  > &nbsp; '.$latest.'</td>
  </tr>
</table><hr>';
		}
		else{
		
		$this->output .='<table  >
  <tr>
    <td rowspan="3"><img style="border-radius:10px;" src="userpix/'.$picture.'" height="60px" width="70px" ></a></td>
    <td>  <a href="#lmp" onClick="update('.$user_id.');"> '.strtoupper($user_full_name)." </a><br><b>School:</b> ".$user_school."  ".'<br><b>Department:</b> '.$dept.'</td>
  </tr>
  <tr>
    <td><img  src="icons/04-squiggle.png"  > &nbsp; '.$latest.'</td>
  </tr>
</table><hr>';
		
		
		
		/*'<p><table  >
  <tr>
    <td rowspan="3"><a href="#lmp" onClick="update('.$user_id.');"><img style="border-radius:10px;"  src="userpix/'.$picture.'" height="60px" width="70px" ></a></td>
    <td>   &nbsp; &nbsp;'.strtoupper($user_full_name)."&nbsp; &nbsp;&nbsp; &nbsp;<font color='#006699'> ".$follow." followers</font>".'<br><h4>&nbsp; &nbsp;Status: '.$status.'</h4></td>
  </tr>
  <tr>
    <td><img style="border-radius:10px;"  src="img/arrow1.png" height="10px" width="10px" > &nbsp;'.$latest.'</td>
  </tr>
</table></p><hr>';*/
		}
					/*$this->output .='
					<li><img style="border-radius:20px;"  src="userpix/'.$picture.'" height="50px" width="60px" ><a href="#lmp" onClick="update('.$user_id.');">'.$user_full_name.': '.$status.'</a></li>';*/
			}
				//$this->output .=' </ul></div>';
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output;
	}
	public function loadInnerLodgeMate($lodge_name)
	{	
		
		$sql="select * from tbl_user where 	user_lodge=:user_lodge";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_lodge'=>$lodge_name));
		
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("user_full_name",$user_full_name);
		$query->bindColumn("user_school",$user_school);
		$query->bindColumn("user_lodge",$user_lodge);
		$query->bindColumn("user_gender",$user_gender);
		$query->bindColumn("user_number",$user_number);
		if($query->rowCount()==0)
		{
			//$this->output= "No User Found in this Lodge";
		}
		else
		{                  

			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
					@$return.=$user_full_name;
			}
				//$this->output .=' </ul>';
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			return $return;
	}
	public function loadAnotherLodgeMate($lodgId,$myPhone)
	{	
		
		$sql="select * from tbl_lodge where lodge_id=:lodge_id limit 1";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':lodge_id'=>$lodgId));
		
		
		$query->bindColumn("lodge_id",$lodge_id);
		$query->bindColumn("lodge_name",$lodge_name);
		$query->bindColumn("school_id",$school_id);
	
		if($query->rowCount()==0)
		{
			//$this->output= "No User Found in this Lodge";
		}
		else
		{                  
           
			while($query->fetch(PDO::FETCH_BOTH))
			{	
					
					///////////////////////////////query for inner Lodge/////////////////////////////////////////
									$sql="select * from tbl_user where 	user_lodge=:user_lodge and user_number!=:myPhone";
									
									$query=$this->conn->prepare($sql);
									$query->execute(array(':user_lodge'=>$lodge_name,':myPhone'=>$myPhone));
									
									
									$query->bindColumn("user_id",$user_id);
									$query->bindColumn("user_full_name",$user_full_name);
									$query->bindColumn("user_school",$user_school);
									$query->bindColumn("user_lodge",$user_lodge);
									$query->bindColumn("user_gender",$user_gender);
									$query->bindColumn("user_number",$user_number);
									$query->bindColumn("status",$status);
									$query->bindColumn("picture",$picture);
									$query->bindColumn("dept",$dept);
									if($query->rowCount()==0)
									{
								     $this->output= "No User Found in this Lodge";
									}
									else
		{                  
		$this->output= '<center> <a href="#WarningM"  onClick="getLodgeId('.$lodge_id.');" data-rel="popup" data-position-to="window" class="ui-btn ui-corner-all ui-shadow ui-btn-inline ui-icon-check ui-btn-icon-left ui-btn-a" data-transition="pop">Enter<br> Group Chat with Students in<br> '.strtoupper($lodge_name).' <img src="http://localhost/panel-styling/icons/53-house.png"> From '.$school_id.' '.'</a></center><br><hr>';
		
          /* $this->output='<div data-role="popup" id="popupMenu" data-theme="b">
					<ul data-role="listview" data-inset="true" style="min-width:210px;">';*/
		while($query->fetch(PDO::FETCH_BOTH))
		  {	
			$latest=selectData::updateChatByUser($user_number,$user_full_name,$myPhone);
			$follow=selectData::followcount2($user_number);
			
			
		if($picture=="")
		{
				$this->output .=

'<div data-role="collapsible" data-collapsed-icon="carat-d" data-expanded-icon="carat-u">
    <h4><img style="border-radius:5px;"  src="userpix/patient.png" height="30px" width="30px" >&nbsp; &nbsp;&nbsp; &nbsp;'.strtoupper($user_full_name).'</h4>
    <ul data-role="listview" data-inset="false">
       <li>Department:&nbsp;'.$dept.'  </li>
        <li>Followers:<font color="#FF0000">'.$follow.'</font>&nbsp;&nbsp;Mobile Number: &nbsp;<font color="#FF0000">'.$user_number.'</font></li>
        <li> <a href="#lmp" onClick="update('.$user_id.');">Chat Now >> </a> </li>
        
    </ul>
</div>';
		}
		else{
		
		$this->output .='<div data-role="collapsible" data-collapsed-icon="carat-d" data-expanded-icon="carat-u">
    <h4><img style="border-radius:5px;"  src="userpix/'.$picture.'"  height="30px" width="30px" >&nbsp; &nbsp;&nbsp; &nbsp;'.strtoupper($user_full_name).'</h4>
    <ul data-role="listview" data-inset="false">
       <li>Department:&nbsp;'.$dept.'  </li>
        <li>Followers:<font color="#FF0000">'.$follow.'</font>&nbsp;&nbsp;Mobile Number: &nbsp;<font color="#FF0000">'.$user_number.'</font></li>
        <li> <a href="#lmp" onClick="update('.$user_id.');">Chat Now >> </a> </li>
        
    </ul>
</div>';
		}
		
			}
				
		}
								
					//////////////////////////////////////////////////////////////////////////
					
					
					
			}
				
		}
		
			echo $this->output;
	}
	/*public function updateChat()
	{	
		
		$sql="select * from tbl_chat where who:who ORDER BY DESC limit 1";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':who'=>0));
		
		
		$query->bindColumn("name",$name);
		$query->bindColumn("message",$message);
		$query->bindColumn("dateOfchat",$date);
		
		if($query->rowCount()==0)
			$this->output= "";
		else
		{                  
			$this->output='';
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
					$this->output =json_encode($name." ".$message." ".$date);
			}
				
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output =json_encode($name." ".$message." ".$date);
	}*/
	/*public function loaduser($user_number)
	{	
		
		$sql="select * from tbl_user where user_number=:user_number limit 1";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_number'=>$user_number));
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("user_full_name",$user_full_name);
		$query->bindColumn("user_school",$user_school);
		$query->bindColumn("user_lodge",$user_lodge);
		$query->bindColumn("user_gender",$user_gender);
		$query->bindColumn("user_email",$user_email);
		
		$_SESSION['lodge']=$user_lodge;
        $_SESSION['number']=$user_number; 
		                                          
		if($query->rowCount()==0)
			$this->output= "No Product yet. Please select another from the categories list.";
		else
		{                  
			$this->output='';
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
					$this->output =json_encode($user_full_name. "  From ". $user_school." Living in ".$user_lodge);
			}
				
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output =json_encode($user_full_name. "  From ". $user_school." Living in ".$user_lodge);
			
	}*/
	
	public function loadUserLodgeMate()
	{	
		$lodge=$_SESSION['lodge'];
		$sql="select * from tbl_user where user_lodge=:user_lodge limit 1";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_number'=>$lodge));
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("user_full_name",$user_full_name);
		$query->bindColumn("user_school",$user_school);
		$query->bindColumn("user_lodge",$user_lodge);
		$query->bindColumn("user_gender",$user_gender);
		$query->bindColumn("user_email",$user_email);
		                                          
		if($query->rowCount()==0)
			$this->output= "No Product yet. Please select another from the categories list.";
		else
		{                  
			$this->output='';
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
					$this->output =json_encode($user_full_name. "  From ". $user_school." Living in ".$user_lodge);
			}
				
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output =json_encode($user_full_name. "  From ". $user_school." Living in ".$user_lodge);
	}
	public function readTimeLectures($myPhone)
	{	
	
	$myPhone=$_SESSION['user_phone'];
	for($i=0;$i<=4;$i++){
		$day[0]="monday";
		$day[1]="tuesday";
		$day[2]="wednesday";
		$day[3]="thursday";
		$day[4]="friday";
	    
		
			
		$sql="select * from lecture_lecture_timetable where user_phone=:user_phone and Type=:Type and Day=:Day";
		
		$query=$this->conn->prepare($sql);
		
		$query->execute(array(':user_phone'=>$myPhone,':Type'=>"Lecture",':Day'=>$day[$i]));
		
		//$query->bindColumn("user_id",$user_id);
		$query->bindColumn("Day",$Day);
		$query->bindColumn("Course",$Course);
		$query->bindColumn("venue",$venue);
		$query->bindColumn("FromT",$FromT);
		$query->bindColumn("ToT",$ToT);
		$query->bindColumn("am_pm",$am_pm);
		                                        
		if($query->rowCount()==0)
			$this->output.= strtoupper($day[$i]).":<br>    Free Lecture Day...<br><hr>";
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			/*if($Day=="monday")
				$day="Monday";
				else if($Day=="tuesday")
				$day="Tuesday";
				else if($Day=="wednesday")
				$day="Wednesday";
				else if($Day=="thursday")
				$day="thursday";
				else if($Day=="friday"){
				$day="Friday";
				}*/
				$this->output .=strtoupper($day[$i]);
					$this->output .=" <br> Course : <b>".$Course."</b> <br> Venue : <b>".$venue."</b> <br> From : <b>".$FromT."</b>  To : <b>".$ToT."</b>  <b>".$am_pm."</b><br><br>";
			}
				$this->output .="<hr>";
		}
	}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output;
	
	}
	public function readContactToDBase($Number)
	{	
		$sql="select * from tbl_user where user_number=:user_number";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_number'=>$Number));
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("user_full_name",$user_full_name);
		$query->bindColumn("user_school",$user_school);
		$query->bindColumn("user_lodge",$user_lodge);
		$query->bindColumn("user_gender",$user_gender);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("status",$status);
		$query->bindColumn("picture",$picture);
		                                        
		if($query->rowCount()==0)
			$this->output.= ":<br>   invite Friend to Lodgechat <hr>";
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
		
				
					$this->output .="<br><b><img src='userpix/".$picture."'width='100px' height='100px' style='border-radius:7px; border-style:groove;'></b> <br>UserName : <b>".$user_full_name."</b> <br> School : <b>".$user_school."</b> <br> Lodge/Hostel : <b>".$user_lodge."</b> Status: <b>".$status."</b>  <b>".$user_gender."</b><br><br>";
			}
				$this->output .="<hr>";
		
	}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output;
	}
	public function readTimeTableR($myPhone)
	{	
			$myPhone=$_SESSION['user_phone'];
		for($i=0;$i<=4;$i++){
		$day[0]="monday";
		$day[1]="tuesday";
		$day[2]="wednesday";
		$day[3]="thursday";
		$day[4]="friday";
	    
		
			
		$sql="select * from lecture_lecture_timetable where user_phone=:user_phone and Type=:Type and Day=:Day";
		
		$query=$this->conn->prepare($sql);
		
		$query->execute(array(':user_phone'=>$myPhone,':Type'=>"Reading",':Day'=>$day[$i]));
		
		//$query->bindColumn("user_id",$user_id);
		$query->bindColumn("Day",$Day);
		$query->bindColumn("Course",$Course);
		$query->bindColumn("venue",$venue);
		$query->bindColumn("FromT",$FromT);
		$query->bindColumn("ToT",$ToT);
		$query->bindColumn("am_pm",$am_pm);
		                                        
		if($query->rowCount()==0)
			$this->output.= strtoupper($day[$i]).":<br>    Free Lecture Day...<br><hr>";
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
		
				$this->output .=strtoupper($day[$i]);
					$this->output .=" <br> Course : <b>".$Course."</b> <br> Venue : <b>".$venue."</b> <br> From : <b>".$FromT."</b>  To : <b>".$ToT."</b>  <b>".$am_pm."</b><br><br>";
			}
				$this->output .="<hr>";
		}
	}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output;
	}
	public function alarm($myPhone)
	{	
		
		$am_pm=date('A');
		$mydate=strtolower(date("l"));
		$myhour=date('h')-1;
		
	//$myPhone=$_SESSION['user_phone'];
		
		$sql="select * from lecture_lecture_timetable where user_phone=:user_phone and Day=:date and FromT=:hour and switch=:switch and am_pm=:am_pm" ;
		
		$query=$this->conn->prepare($sql);
		
		$query->execute(array(':user_phone'=>$myPhone,':date'=>$mydate,':hour'=>$myhour,':switch'=>"ON",':am_pm'=>$am_pm));
		
		//$query->bindColumn("user_id",$user_id);
		$query->bindColumn("Day",$Day);
		$query->bindColumn("Course",$Course);
		$query->bindColumn("venue",$venue);
		$query->bindColumn("FromT",$FromT);
		$query->bindColumn("ToT",$ToT);
		$query->bindColumn("am_pm",$am_pm);
		                                          
		if($query->rowCount()==0){
			$correct=$this->checkAlarm($mydate,$myhour,$myPhone,$am_pm);
			
			@updateData::alarmOParetion($mydate,$correct,$myPhone);
			$this->output=0;//$correct;//"No Time Table yet. Go to Setting to set your Time Table".$myPhone.$mydate.$myhour;
			
		}
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
				
				updateData::updateAlarm($myPhone,$mydate,$myhour);
				
					$this->output .=" On ".$Day."You Have  ".$Course."  Venue :  ".$venue."    From :  ".$FromT."</b>  To : ".$ToT."    ".$am_pm."";
			}
				
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			echo $this->output;
	}
	public function loadAdvert($school)
	{	
		
	
	
		
		$sql="select * from tbl_advert where school=:school limit 2 " ;
		
		$query=$this->conn->prepare($sql);
		
		$query->execute(array(':school'=>$school));
		
		//$query->bindColumn("user_id",$user_id);
		$query->bindColumn("heading1",$heading1);
		$query->bindColumn("advert1",$advert1);
		$query->bindColumn("phone",$phone);
		                                          
		if($query->rowCount()==0){
			
			$this->output="";
			
		}
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			
					$this->output .=" <marquee direction='right'>".$advert1."</marquee>";
			}
				
		}
			echo $this->output;
	}
	public function checkAlarm($mydate,$myhour,$myPhone,$am_pm)
	{	
		$myhour=abs(date('h')-2);
		
		//$myPhone=$_SESSION['user_phone'];
		$sql="select * from lecture_lecture_timetable where user_phone=:user_phone and Day=:date and FromT=:hour and am_pm=:am_pm";
		
		$query=$this->conn->prepare($sql);
		
		$query->execute(array(':user_phone'=>$myPhone,':date'=>$mydate,':hour'=>"N".$myhour,':am_pm'=>$am_pm));
		
		//$query->bindColumn("user_id",$user_id);
		$query->bindColumn("Day",$Day);
		$query->bindColumn("Course",$Course);
		$query->bindColumn("venue",$venue);
		$query->bindColumn("FromT",$FromT);
		$query->bindColumn("ToT",$ToT);
		$query->bindColumn("am_pm",$am_pm);
		                                          
		if($query->rowCount()==0){
			//$this->output= "No ";//Time Table yet. Go to Setting to set your Time Table".$myPhone.$mydate.$myhour;
			//updateData::alarmOParetion($mydate,$myhour,$myPhone);
		}
		else
		{                  
			
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				
				
				//updateData::updateAlarm($myPhone,$mydate,$myhour);
				
					$this->output=$FromT;
					
			}
				
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			return $this->output;
	}
	
	
	public function countMember($lodge_name)
	{	
		
		$sql="select * from tbl_user where 	user_lodge=:user_lodge";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_lodge'=>$lodge_name));
		
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("user_lodge",$user_lodge);
		
		if($query->rowCount()==0)
		{
			@$count=0;
			//$this->output= "No User Found in this Lodge";
		}
		else
		{                  
        @$count=$query->rowCount();
			
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			return $count;
	}
	
	
	public function loadAllLodges($domain_school)
	{	
		//$lodge=$_SESSION['lodge'];
		
		$sql="select * from tbl_lodge where school_id=:value and status=:status order by rand() ";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':value'=>$domain_school,':status'=>"C"));
		
		$query->bindColumn("lodge_id",$lodge_id);
		$query->bindColumn("lodge_name",$lodge_name);
		$query->bindColumn("school_id",$school_id);
	
	                        
		if($query->rowCount()==0)
			$this->output= "No Lodge Found.";
		else
		{                  
		
				$num=0;
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			@$count=selectData::countMember($lodge_name); 
					/*$this->output .=' <a href="#chat" ><a class="btn btn-block" onClick="getAnotherLodge('.$lodge_id.');">'.$lodge_name.'[ '.$count.' ]  </a> ';
			}
				*/
				
			/*	
				$this->output .='<ul data-role="listview" data-inset="true">
        <li><a href="#page9" onClick="getAnotherLodge('.$lodge_id.');">'.$lodge_name.'( '.$count.'  )  Student(s)   '.'" </a></li>
           
            </ul>';*/
				$this->output .=' <ul data-role="listview"  data-inset="true"> 
		<a href="#lodgeMates" ><input type="button" id="" onClick="getAnotherLodge('.$lodge_id.');"  value="'.$lodge_name.'( '.$count.'  )  Student(s)   '.'" /></a></ul>';
			}
				
				
		}
			echo $this->output;
	}
	public function loadallSlodges($domain_school)
	{	
		//$lodge=$_SESSION['lodge'];
		
		$sql="select * from tbl_lodge where school_id=:value and status=:status order by rand() ";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':value'=>$domain_school,':status'=>"S"));
		
		$query->bindColumn("lodge_id",$lodge_id);
		$query->bindColumn("lodge_name",$lodge_name);
		$query->bindColumn("school_id",$school_id);
	
	                        
		if($query->rowCount()==0)
			$this->output= "No Suggested Lodge Found.";
		else
		{                  
		
				$num=0;
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			@$count=selectData::countMember($lodge_name); 
					/*$this->output .=' <a href="#chat" ><a class="btn btn-block" onClick="getAnotherLodge('.$lodge_id.');">'.$lodge_name.'[ '.$count.' ]  </a> ';
			}
				*/
				
			/*	
				$this->output .='<ul data-role="listview" data-inset="true">
        <li><a href="#page9" onClick="getAnotherLodge('.$lodge_id.');">'.$lodge_name.'( '.$count.'  )  Student(s)   '.'" </a></li>
           
            </ul>';*/
				$this->output .=' <ul data-role="listview"  data-inset="true"> 
		<a href="#lodgeMates" ><input type="button" id="" onClick="getAnotherLodge('.$lodge_id.');"  value="'.$lodge_name.'( '.$count.'  )  Student(s)   '.'" /></a></ul>';
			}
				
				
		}
			echo $this->output;
	}
	public function loadSearchLodge($searchvalue,$domain_school)
	{	
		//$lodge=$_SESSION['lodge'];
		$sql="select * from tbl_lodge where lodge_name like :searchvalue and school_id=:domain_school order by lodge_name ASC";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':searchvalue'=>"%".$searchvalue."%",':domain_school'=>$domain_school));
		
		
		$query->bindColumn("lodge_id",$lodge_id);
		$query->bindColumn("lodge_name",$lodge_name);
		$query->bindColumn("school_id",$school_id);
	
		                                          
		if($query->rowCount()==0)
			$this->output= "No Lodge Found with the name <b>".$searchvalue. "</b> in <b>".$domain_school."</b>";
		else
		{                  
		
				$num=0;
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			@$count=selectData::countMember($lodge_name); 
					$this->output .=' <ul data-role="listview"  data-inset="true"> 
		<a href="#lodgeMates" ><input type="button" id="" onClick="getAnotherLodge('.$lodge_id.');"  value="'.$lodge_name.'( '.$count.'  )  Student(s)   '.'" /></a></ul>';
			}
			
				
		}
			echo $this->output;
	}
	
	
		public function getImage($phone)
     	{	
		
		$sql="select * from tbl_user where 	user_number=:user_number";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_number'=>$phone));
		
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("picture",$picture);
		
		if($query->rowCount()==0)
		{
			@$pix="patient.png";
			//$this->output= "No User Found in this Lodge";
		}
		else
		{                  
         while($query->fetch(PDO::FETCH_BOTH))
			{	
			@$pix=$picture;
			}			
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			return $pix;
	}
	public function getID($phone)
     	{	
		
		$sql="select * from tbl_user where 	user_number=:user_number";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_number'=>$phone));
		
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("picture",$picture);
		
		if($query->rowCount()==0)
		{
			//@$pix="patient.png";
			//$this->output= "No User Found in this Lodge";
		}
		else
		{                  
         while($query->fetch(PDO::FETCH_BOTH))
			{	
			@$pix=$user_id;
			}			
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			return $pix;
	}
	public function getImageHole()
     	{	
		
		$sql="select * from tbl_comment where status!=:user_number";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_number'=>""));
		
		
		$query->bindColumn("status",$status);
		
		
		if($query->rowCount()==0)
		{
			@$answer="";
			//$this->output= "No User Found in this Lodge";
		}
		else
		{                  
         	@$answer=$status;		
		}
		//$this->output =array("success"=>1,"Msg"=>$user_full_name);
			return $answer;
	}
	
	public function checkForUploaded($commentByUser,$UserName,$date,$school,$domain_school,$phoneNumber,$profileLodge)
	{	
	    @$getImageHole=selectData::getImageHole();
		if($getImageHole!=""){
			@updateData::updateCommentRecord($commentByUser,$UserName,$date,$school,$domain_school,$phoneNumber,$profileLodge,$getImageHole);
		}
		else{
		}
	
			//echo $result;
			
	}
	public function LoadGroups($domain_school)
	{	
		//$lodge=$_SESSION['lodge'];
		$sql="select * from tbl_group where school=:domain_school  order by SgroupName ASC";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':domain_school'=>$domain_school));
		
		
		$query->bindColumn("id",$id);
		$query->bindColumn("date",$date);
		$query->bindColumn("school",$school);
		$query->bindColumn("dept",$dept);
	    $query->bindColumn("SgroupName",$SgroupName);
		//$this->output= "No Lodge Found with the name <b>".$searchvalue. "</b> in <b>".$domain_school."</b>";
		if($query->rowCount()==0){
		}
		else
		{                  
		
				//$num=0;
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			  @$time=selectData::timeBetween($date,time());
			//@$count=selectData::countMember($lodge_name); 
			$this->output .='<font color="#FFFFFF"><input value="'.$SgroupName.' Created '.$time.' '.'"   onClick="joinGroup('.$id.');"  type="button"></font>';
					
			}
			
				
		}
			echo $this->output;
	}
	public function getGroupName($id)
	{	
		//$lodge=$_SESSION['lodge'];
		$sql="select * from tbl_group where id=:id";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':id'=>$id));
		
		
		$query->bindColumn("id",$id);
		$query->bindColumn("date",$date);
		$query->bindColumn("school",$school);
		$query->bindColumn("dept",$dept);
	    $query->bindColumn("SgroupName",$SgroupName);
		//$this->output= "No Lodge Found with the name <b>".$searchvalue. "</b> in <b>".$domain_school."</b>";
		if($query->rowCount()==0){
			@$r=="";
		}
		else
		{                  
		
				//$num=0;
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			 
			//@$count=selectData::countMember($lodge_name); 
			@$r=$SgroupName;
					
			}
			
				
		}
			return $r;
	}
	public function LoadUserGroups($domain_school,$phoneNumber)
	{	
		//$lodge=$_SESSION['lodge'];
		$sql="select * from tbl_groupmembers where school=:school AND number=:number order by id ASC";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':school'=>$domain_school,':number'=>$phoneNumber));
		
		
		$query->bindColumn("id",$id);
		$query->bindColumn("date",$date);
		$query->bindColumn("school",$school);
		$query->bindColumn("group_id",$group_id);
	    //$query->bindColumn("SgroupName",$SgroupName);
		//$this->output= "No Lodge Found with the name <b>".$searchvalue. "</b> in <b>".$domain_school."</b>";
		if($query->rowCount()==0){
			$this->output="No Group joined Yet";
		}
		else
		{                  
		
				//$num=0;
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			 // @$time=selectData::timeBetween($date,time());
			  @$Groupname=selectData::getGroupName($group_id);
			//@$count=selectData::countMember($lodge_name); 
			$this->output .='<font color="#FFFFFF"><a href="#groupWall"><input value="'.$Groupname.' "   onClick="loadGroupContent('.$id.');"  type="button"></a></font>';
					
			}
			
				
		}
			echo $this->output;
	}
	public function joinGroup($id,$UserName,$date,$profileSchool,$profileLodge,$phoneNumber)
	{	
		//$lodge=$_SESSION['lodge'];
		$sql="select * from tbl_groupmembers where group_id=:id AND number=:number";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':id'=>$id,':number'=>$phoneNumber));
		
		
		$query->bindColumn("id",$idd);
		$query->bindColumn("date",$date2);
		$query->bindColumn("school",$school);
		//$this->output= "No Lodge Found with the name <b>".$searchvalue. "</b> in <b>".$domain_school."</b>";
		if($query->rowCount()==0){
			
			insertData::joinGroupUser($id,$UserName,$date,$profileSchool,$profileLodge,$phoneNumber);
			$this->output ="You have Successfuly Joined this Group";
			
		}
		else
		{                  
		
				//$num=0;
			while($query->fetch(PDO::FETCH_BOTH))
			{	
			 // @$time=selectData::timeBetween($date,time());
			//@$count=selectData::countMember($lodge_name); 
			$this->output ="Sorry ".$UserName."  you are a Member of this Group...";
			
					
			}
			
				
		}
			echo $this->output;
	}
	public function loadComment($numOfPAge,$domain_school,$phoneNumber)
	{	
		$sql="select * from tbl_comment where comment!=:value and domain_school=:domain_school order by id desc limit $numOfPAge ";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':value'=>"",':domain_school'=>$domain_school));

		$query->bindColumn("id",$id);
		$query->bindColumn("comment",$comment);
		$query->bindColumn("fullname",$fullname);
		$query->bindColumn("date",$date);
	    $query->bindColumn("lodge",$lodge);
		$query->bindColumn("school",$school);
		$query->bindColumn("phone",$phone);
		$query->bindColumn("pix",$pixx);
		                                          
		if($query->rowCount()==0)
			$result= "No Posts Found in ".$domain_school;
		else
		{         $this->output .= '<hr>';       
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				/*for($i=0;$i<=$id;$i++){
	         	$day[]=$id;*/
				//onClick="update('.$user_id.');"
				@$user_id=selectData::getID($phone);
				@$pix=selectData::getImage($phone);
				@$sub=selectData::subcomment($id);
                @$time=selectData::timeBetween($date,time());
/*				if($pix=""){$pix="patient.png";}
*/				if($pixx==""){
	             $comment=htmlspecialchars($comment);
                  }
				  else{
				  $comment='<img src="uploads/'.$pixx.'" width="300px" height="200px" style="border-radius:7px; border-style:groove;"><br><b>'. $comment.'</b>';
				  }
				  if($phoneNumber==$phone){
					  $deleteOption='<a href="#" class="ui-btn ui-shadow ui-corner-all ui-icon-delete ui-btn-icon-notext ui-btn-b ui-btn-inline" onClick="deletePost('.$id.');" >Delete</a>';
				  }
				  else{
					  $deleteOption="";
				  }
				@$result .='<div class="ui-corner-all custom-corners" style="word-wrap: break-word;"><div class="ui-bar ui-bar-a"> <h3> <img src="userpix/'.$pix.'" width="40px;" height="40px;" style="border-radius:20px;"><font color="#FFFFFF"> '.strtoupper($fullname).' <img src="icons/140-gradhat.png"> '.$school.'</font> '.$deleteOption.'</h3> </div>  <div class="ui-body ui-body-a"><b>'.$comment.'</b><br><img src="icons/11-clock.png" width="10px;" hieght="10px;"> '.$time.'<hr>
				<center><div class="ui-alt-icon">
				<a href="#viewProfile" onClick="viewProfile('.$phone.');" class="ui-btn ui-shadow ui-corner-all ui-icon-eye ui-btn-icon-notext ui-btn-b ui-btn-inline">Check</a>
    
    <a href="#lmp" onClick="update('.$user_id.');" class="ui-btn ui-shadow ui-corner-all ui-icon-comment ui-btn-icon-notext ui-btn-b ui-btn-inline">Check</a> 
	
	<a href="#" class="ui-btn ui-shadow ui-corner-all ui-icon-forward ui-btn-icon-notext ui-btn-b ui-btn-inline">Delete</a>
</div></center>


				<br><textarea cols="20" rows="1" id="ken'.$id.'neth"></textarea><button type="submit" onClick="subcomment('.$id.');"> Comment </button><br>'.$sub.' </div></div><br>';
					/*@$result .="<h6><img src='userpix/".$_SESSION['picture']."' width='50px;' hieght='50px;' style='border-radius:20px;'><img src='icons/04-squiggle.png' width='20px;' hieght='20px;'><b>".strtoupper($fullname)."</b> <img src='icons/148-doghouse.png' width='20px;' hieght='20px;'> <b>".strtoupper($lodge)."</b> <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color='#000066'> ".htmlspecialchars($comment)." </font> <b> <img src='icons/11-clock.png' width='10px;' hieght='10px;'> ".$time."</b><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<textarea id='ken".$id."neth'></textarea>&nbsp;&nbsp;<button type='submit' onClick='subcomment(".$id.");'> Comment </button><br>".$sub."<br><hr></h6>";*/
			}
				
				
		//}
		}
			echo $result;
	}
	public function loadGroupContent($GnumOfPAge,$id)
	{	
		$sql="select * from tbl_groupcomment where group_id=:group_id order by id desc limit $GnumOfPAge ";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':group_id'=>$id));

		$query->bindColumn("id",$idd);
		$query->bindColumn("comment",$comment);
		$query->bindColumn("fullname",$fullname);
		$query->bindColumn("date",$date);
	    $query->bindColumn("lodge",$lodge);
		$query->bindColumn("school",$school);
		$query->bindColumn("phone",$phone);
		$query->bindColumn("pix",$pixx);
		                                          
		if($query->rowCount()==0)
			$result= "No Post on this Group";
		else
		{         $this->output .= '<hr>';       
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				/*for($i=0;$i<=$id;$i++){
	         	$day[]=$id;*/
				//onClick="update('.$user_id.');"
				@$user_id=selectData::getID($phone);
				@$pix=selectData::getImage($phone);
				//@$sub=selectData::subcomment($id);
                @$time=selectData::timeBetween($date,time());
/*				if($pix=""){$pix="patient.png";}
*/				if($pixx==""){
	             $comment=htmlspecialchars($comment);
                  }
				  else{
				  $comment='<img src="uploads/'.$pixx.'" width="300px" height="200px" style="border-radius:7px; border-style:groove;"><br><b>'. $comment.'</b>';
				  }
				/*  if($phoneNumber==$phone){
					  $deleteOption='<a href="#" class="ui-btn ui-shadow ui-corner-all ui-icon-delete ui-btn-icon-notext ui-btn-b ui-btn-inline" onClick="deletePost('.$id.');" >Delete</a>';
				  }
				  else{
					  $deleteOption="";
				  }*/
				@$result .='<div class="ui-corner-all custom-corners" style="word-wrap: break-word;"><div class="ui-bar ui-bar-a"> <h3> <img src="userpix/'.$pix.'" width="40px;" height="40px;" style="border-radius:20px;"><font color="#FFFFFF"> '.strtoupper($fullname).' <img src="icons/140-gradhat.png"> '.$school.'</font> '.$deleteOption.'</h3> </div>  <div class="ui-body ui-body-a"><b>'.$comment.'</b><br><img src="icons/11-clock.png" width="10px;" hieght="10px;"> '.$time.'<hr>
				<center><div class="ui-alt-icon">
				<a href="#viewProfile" onClick="viewProfile('.$phone.');" class="ui-btn ui-shadow ui-corner-all ui-icon-eye ui-btn-icon-notext ui-btn-b ui-btn-inline">Check</a>
    
    <a href="#lmp" onClick="update('.$user_id.');" class="ui-btn ui-shadow ui-corner-all ui-icon-comment ui-btn-icon-notext ui-btn-b ui-btn-inline">Check</a> 
	
	<a href="#" class="ui-btn ui-shadow ui-corner-all ui-icon-forward ui-btn-icon-notext ui-btn-b ui-btn-inline">Delete</a>
</div></center>


				 </div></div><br>';
					/*@$result .="<h6><img src='userpix/".$_SESSION['picture']."' width='50px;' hieght='50px;' style='border-radius:20px;'><img src='icons/04-squiggle.png' width='20px;' hieght='20px;'><b>".strtoupper($fullname)."</b> <img src='icons/148-doghouse.png' width='20px;' hieght='20px;'> <b>".strtoupper($lodge)."</b> <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<font color='#000066'> ".htmlspecialchars($comment)." </font> <b> <img src='icons/11-clock.png' width='10px;' hieght='10px;'> ".$time."</b><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<textarea id='ken".$id."neth'></textarea>&nbsp;&nbsp;<button type='submit' onClick='subcomment(".$id.");'> Comment </button><br>".$sub."<br><hr></h6>";*/
			}
				
				
		//}
		}
			echo $result;
	}
	public function subcomment($id)
	{	
		$sql="select * from tbl_subcomment where comment_id=:comment_id order by id desc limit 10 ";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':comment_id'=>$id));

		$query->bindColumn("id",$id);
		$query->bindColumn("comment",$comment);
		$query->bindColumn("sender",$fullname);
		$query->bindColumn("date",$date);
	    $query->bindColumn("lodge",$lodge);
		$query->bindColumn("school",$school);
	    $query->bindColumn("phone",$phone);                                        
		if($query->rowCount()==0)
		{
			$res="";
		}
		else
		{                  
			while($query->fetch(PDO::FETCH_BOTH))
			{	
				/*for($i=0;$i<=$id;$i++){
	         	$day[]=$id;*/
				
                @$time=selectData::timeBetween($date,time());
                @$pix=selectData::commentpix($phone);
				
					@$res .="&nbsp;<img src='userpix/".$pix."' width='40px;' hieght='40px;' style='border-radius:20px;'><img src='icons/04-squiggle.png' width='20px;' hieght='20px;'>: <a href='#viewProfile' onClick='vProfile(".$phone.");' > ".$fullname."</a><br><b>School: </b>".$school." <br> <img src='icons/124-bullhorn.png' width='10px;' height='10px;'> <font color='#000066'> ".htmlspecialchars($comment)." </font> <b> <br><img src='icons/11-clock.png' width='10px;' hieght='10px;'> &nbsp;".$time."</b><br><hr>";
			}
				
				
		//}
		}
			return $res;
	}
	
	public function commentpix($phone)
	{	
		
		$sql="select * from tbl_user where   user_number=:phone";
		
		$query=$this->conn->prepare($sql);
		$query->execute(array(':phone'=>$phone));
		
		
		$query->bindColumn("user_id",$user_id);
		$query->bindColumn("user_full_name",$user_full_name);
		$query->bindColumn("user_school",$user_school);
		$query->bindColumn("user_lodge",$user_lodge);
		$query->bindColumn("user_gender",$user_gender);
		$query->bindColumn("user_number",$user_number);
		$query->bindColumn("picture",$picture);
		$query->bindColumn("status",$status);
		if($query->rowCount()==0)
			$result= "";
		else
		{                  

				while($query->fetch(PDO::FETCH_BOTH))
			{	
			
			
			/*'<div id="tryuser"> <ul data-role="listview"  data-inset="true"> 
		<a href="#lmp" ><img src="icons/77-ekg.png" /><input type="button" id="" onClick="update('.$user_id.');" name="user_full_name" value="['.$user_full_name.']'.'" /></a>: '.$status.'</hr><br><div id="latestChat"></div>';*/
		if($picture=="")
		{
				$result ='patient.png';
		}
		else{
		
		$result =$picture;
		}
			}
		}
			return $result;
	}
	
	
	 function timeBetween($start,$end){
    	$time = $end - $start;
    
    	if($time <= 60){
    		return 'one moment ago';
    	}
    	if(60 < $time && $time <= 3600){
    		return round($time/60,0).' minutes ago';
    	}
    	if(3600 < $time && $time <= 86400){
    		return round($time/3600,0).' hours ago';
    	}
    	if(86400 < $time && $time <= 604800){
    		return round($time/86400,0).' days ago';
    	}
    	if(604800 < $time && $time <= 2592000){
    		return round($time/604800,0).' weeks ago';
    	}
    	if(2592000 < $time && $time <= 29030400){
    		return round($time/2592000,0).' months ago';
    	}
    	if($time > 29030400){
    		return date('M d y at h:i A',$start);
    	}
    }   
}
?>