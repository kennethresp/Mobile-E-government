<?php
class insertData extends dbconnect
{
	private $output;
	public function __construct(){
		parent::__construct();	
	}

	
	public function send($name,$message,$date,$senderNumber,$recieverNumber,$recievername){
				$sql="insert into tbl_chat(name,message,dateOfchat,sender_Number,reciever_Number,status,recievername) values(:name,:message,:dateOfchat,:sender_Number,:reciever_Number,:status,:recievername)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':name'=>$name,':message'=>$message,':dateOfchat'=>$date,':sender_Number'=>$senderNumber,':reciever_Number'=>$recieverNumber,':status'=>"new",':recievername'=>$recievername));
		
		/*mysql_query("insert into  tbl_chat SET name='$name', message='$massege' , dateOfchat='$date'") or die("cannot save image no sucess ".mysql_error()); */
	}
	public function sendGroupChat($name,$message,$date,$senderNumber,$domain_school,$lodgeId){
				$sql="insert into tbl_groupchat(school,lodgeName,dateOfChat,userName,phone,status,chat) values(:school,:lodgeName,:dateOfChat,:userName,:phone,:status,:chat)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':school'=>$domain_school,':lodgeName'=>$lodgeId,':dateOfChat'=>$date,':userName'=>$name,':phone'=>$senderNumber,':status'=>"new",':chat'=>$message));
		
		/*mysql_query("insert into  tbl_chat SET name='$name', message='$massege' , dateOfchat='$date'") or die("cannot save image no sucess ".mysql_error()); */
	}
	public function sendChatToFollower($pname,$pPrice,$pDesc,$pin,$phone,$myName,$profileId,$follower,$user_full_name,$user_id){
		        $message="<b>New Item From</b> ".$myName."  <b>Item name:</b> ".$pname."  <b>Price: </b>".$pPrice." <b>Descriptions: </b>".$pDesc;
				$sql="insert into tbl_chat(name,message,dateOfchat,sender_Number,reciever_Number,status,recievername) values(:name,:message,:dateOfchat,:sender_Number,:reciever_Number,:status,:recievername)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':name'=>$myName,':message'=>$message,':dateOfchat'=>date("d-m-Y"),':sender_Number'=>$phone,':reciever_Number'=>$follower,':status'=>"new",':recievername'=>$user_full_name));
		
		
	}
  public function comment($commentByUser,$UserName,$date,$school,$domain_school,$phoneNumber,$profileLodge)
	{
		
		$sql="insert into tbl_comment(domain_school,comment,fullname,date,lodge,school,phone,status) values(:domain_school,:comment,:fullname,:date,:lodge,:school,:phone,:status)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':domain_school'=>$domain_school,':comment'=>$commentByUser,':fullname'=>$UserName,':date'=>time(),':lodge'=>$profileLodge,':school'=>$school,':phone'=>$phoneNumber,':status'=>"new"));
	}
	 public function imageComment($commentByUser,$UserName,$date,$school,$domain_school,$phoneNumber,$profileLodge,$uploadPixName)
	{
		
		$sql="insert into tbl_comment(domain_school,comment,fullname,date,pix,lodge,school,phone) values(:domain_school,:comment,:fullname,:date,:pix,:lodge,:school,:phone)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':domain_school'=>$domain_school,':comment'=>$commentByUser,':fullname'=>$UserName,':date'=>time(),':pix'=>$uploadPixName,':lodge'=>$profileLodge,':school'=>$school,':phone'=>$phoneNumber));
	}
	 public function subcomment($commentByUser,$UserName,$date,$id,$domain_school,$profileLodge,$phoneNumber)
	{
		/*$school=$_SESSION['user_school'];
		$UserName=$_SESSION['user_full_name'];
		$lodge= $_SESSION['user_lodge'];*/
		
		$sql="insert into tbl_subcomment(comment_id,comment,sender,date,lodge,school,phone) values(:comment_id,:comment,:fullname,:date,:lodge,:school,:phone)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':comment_id'=>$id,':comment'=>$commentByUser,':fullname'=>$UserName,':date'=>time(),':lodge'=>$lodge,':school'=>$school,':phone'=>$_SESSION['user_phone']));
	}
	 public function SbtnCreateGroup($SgroupName,$UserName,$date,$profileSchool,$profileLodge,$phoneNumber)
	{
		$sql="insert into tbl_group(SgroupName,name,date,lodge,school,phone) values(:SgroupName,:name,:date,:lodge,:school,:phone)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':SgroupName'=>$SgroupName,':name'=>$UserName,':date'=>time(),':lodge'=>$profileLodge,':school'=>$profileSchool,':phone'=>$phoneNumber));
	}
	 public function DbtnCreateGroup($SgroupName,$UserName,$date,$profileSchool,$profileLodge,$phoneNumber,$groupDept)
	{
		$sql="insert into tbl_group(SgroupName,name,date,lodge,school,phone,dept) values(:SgroupName,:name,:date,:lodge,:school,:phone,:dept)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':SgroupName'=>$SgroupName,':name'=>$UserName,':date'=>time(),':lodge'=>$profileLodge,':school'=>$profileSchool,':phone'=>$phoneNumber,':dept'=>$groupDept));
	}
    public function joinGroupUser($id,$UserName,$date,$profileSchool,$profileLodge,$phoneNumber)
	{
		$sql="insert into tbl_groupmembers(group_id,name,date,lodge,school,number) values(:group_id,:name,:date,:lodge,:school,:phone)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':group_id'=>$id,':name'=>$UserName,':date'=>$date,':lodge'=>$profileLodge,':school'=>$profileSchool,':phone'=>$phoneNumber));
			
	} 
	 public function Gcomment($commentByUser,$UserName,$date,$school,$id,$phoneNumber,$profileLodge)
	{
		
		$sql="insert into tbl_groupcomment(domain_school,comment,fullname,date,lodge,school,phone,status,group_id) values(:domain_school,:comment,:fullname,:date,:lodge,:school,:phone,:status,:group_id)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':domain_school'=>"none",':comment'=>$commentByUser,':fullname'=>$UserName,':date'=>time(),':lodge'=>$profileLodge,':school'=>$school,':phone'=>$phoneNumber,':status'=>"new",':group_id'=>$id));
	}

	public function lodgeGossip($gossip,$mylodge,$myName,$date)
	{
		$sql="insert into tbl_gossip(gossip,gossip_owner,gossip_lodge,gossip_date,status) values(:gossip,:gossip_owner,:gossip_lodge,:gossip_date,:status)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':gossip'=>$gossip,':gossip_owner'=>$myName,':gossip_lodge'=>$mylodge,':gossip_date'=>$date,':status'=>"new"));
	}
	public function saveProduct($pname,$pPrice,$pDesc,$pin,$phone,$myName,$profileId)
	{
		$sql="insert into tbl_market(user_number,userName,p_name,p_price,p_desc,pin,date,userid) values(:phone,:userName,:pname,:pPrice,:pDesc,:pin,:date,:userid)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':phone'=>$phone,':userName'=>$myName,':pname'=>$pname,':pPrice'=>$pPrice,':pDesc'=>$pDesc,':pin'=>$pin,':date'=>date("d-m-Y"),':userid'=>$profileId));
			selectData::getIfFollowed($pname,$pPrice,$pDesc,$pin,$phone,$myName,$profileId);
	}
	public function followUser($FollowedNumber,$FollowerNumber,$count)
	{
		$sql="insert into tbl_follow(beenFollowed,follower,count) values(:beenFollowed,:follower,:count)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':beenFollowed'=>$FollowerNumber,':follower'=>$FollowedNumber,':count'=>$count));
	}
		public function SloadAlodge($school,$sLodge)
	{
		$status="S";
		$sql="insert into tbl_lodge(lodge_name,school_id,status) values(:school,:sLodge,:status)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':school'=>$sLodge,':sLodge'=>$school,':status'=>$status));
	}
	public function register($lodge,$school,$fullname,$pwd,$Checknumber,$sex,$college,$dept)
	{	
		$sql="insert into tbl_user(user_number,user_full_name,user_school,user_lodge,user_password,College,user_gender,	dept) values(:user_number,:user_full_name,:user_school,:user_lodge,:user_password,:College,:user_gender,:dept)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':user_number'=>$Checknumber,':user_full_name'=>$fullname,':user_school'=>$school,':user_lodge'=>$lodge,':user_password'=>$pwd,':College'=>$college,':user_gender'=>$sex,':dept'=>$dept));
	}
	public function saveRforLodge($qst1,$qst2,$qst3,$qst4,$number,$name)
	{
		if($qst1=="I Need a Full Bed Space For Sale"){
		$type="HOSTEL";}
		else if($qst1=="I Have a Full Bed Space For Sale"){
		$type="HOSTEL";}
		else if($qst1=="I have a Room and Am looking for a Room Mate"){
		$type="LODGE";}
		else if($qst1=="I Dont have a Room and Am looking for a Room Mate"){
		$type="LODGE";}
		else if($qst1=="I have a Vacant Room For Rent"){
		$type="LODGE";
		}
		       $name=$_SESSION['user_full_name'];
			   
				$number= $_SESSION['user_phone'];
		$sql="insert into 
tbl_vacant(qst1,qst2,qst3,qst4,name,number,type,date) values(:qst1,:qst2,:qst3,:qst4,:name,:number,:type,:date)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':qst1'=>$qst1,':qst2'=>$qst2,':qst3'=>$qst3,':qst4'=>$qst4,':name'=>$name,':number'=>$number,':type'=>$type,':date'=>date("d-m-Y")));
			
	}
	public function setTimeTable($type,$coscode,$venue,$day,$ap,$frm,$to,$myPhone)
	{
		$sql="insert into lecture_lecture_timetable(Day,Course,venue,FromT,ToT,am_pm,Type,user_phone,switch) values(:Day,:Course,:venue,:FromT,:ToT,:am_pm,:Type,:user_phone,:switch)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':Day'=>$day,':Course'=>$venue,':venue'=>$coscode,':FromT'=>$frm,':ToT'=>$to,':am_pm'=>$ap,':Type'=>$type,':user_phone'=>$myPhone,':switch'=>"ON"));
			
			///$this->output=$type.$coscode.$venue.$day.$ap.$frm.$to;
			//echo $this->output;
	}
	public function setTimeTableExma($type,$coscode,$venue,$day,$tym,$myPhone)
	{
		$sql="insert into lecture_lecture_timetable(Day,Course,venue,FromT,ToT,am_pm,Type) values(:Day,:Course,:venue,:FromT,:ToT,:am_pm,:Type)";
			$query=$this->conn->prepare($sql);
			$query->execute(array(':Day'=>$day,':Course'=>$venue,':venue'=>$coscode,':FromT'=>$frm,':ToT'=>$to,':am_pm'=>$ap,':Type'=>$type));
			
			///$this->output=$type.$coscode.$venue.$day.$ap.$frm.$to;
			//echo $this->output;
	}
	
		 
	
}
?>