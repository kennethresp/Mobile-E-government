<?php
class deleteData extends dbconnect
{
	
	public function __construct(){
		parent::__construct();	
	}
	
	public function deleteBusiness($biz_id)
	{
		$sql="update tbl_business set  delete_status=:d_status where id_business=:id_biz";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':id_biz'=>$biz_id,':d_status'=>1));
		
		$this->output =array("success"=>1,"Msg"=>"Business Deleted");
		return json_encode($this->output);
	}
	public function deleteProduct($p_id)
	{
		$sql="update tbl_product set  delete_status=:d_status where id_products=:p_id";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':p_id'=>$p_id,':d_status'=>1));
		
		$this->output =array("success"=>1,"Msg"=>"Business Deleted");
		return json_encode($this->output);
	}
	public function deletePartner($p_id)
	{
		$sql="update tbl_partner set  delete_status=:d_status where partnership_id=:p_id";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':p_id'=>$p_id,':d_status'=>1));
		
		$this->output =array("success"=>1,"Msg"=>"Partnership Deleted. Please wait you are being redirected.");
		return json_encode($this->output);
	}
	public function myShopDelete($pin,$phone,$pix)
	{
		$sql="Delete from tbl_market where user_number=:phone and pin=:pin ";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':phone'=>$phone,':pin'=>$pin));
		//echo $this->output=$pin.$phone.$pix;
	}
	public function deletePost($id)
	{
		$sql="Delete from tbl_comment where id=:id ";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':id'=>$id));
		//echo $this->output=$pin.$phone.$pix;
	}
	public function deleteLectureTimeTable($myPhone)
	{
		$sql="Delete from lecture_lecture_timetable where user_phone=:phone and Type=:type";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':phone'=>$myPhone,':type'=>"Lecture"));
		
	}public function deleteReadingTimeTable($myPhone)
	{
		$sql="Delete from lecture_lecture_timetable where user_phone=:phone and Type=:type";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':phone'=>$myPhone,':type'=>"Reading"));
		
	}
}
?>