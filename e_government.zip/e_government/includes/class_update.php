<?php
class updateData extends dbconnect
{
	private $output;
	
	public function __construct(){
		parent::__construct();	
	}
	

	public function updateGossipRecord($gossip_id)
	{
		$sql="update tbl_gossip set status=:status where gossip_id=:gossip_id";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':status'=>"old",':gossip_id'=>$gossip_id));
	}
	public function updateCommentRecord($commentByUser,$UserName,$date,$school,$domain_school,$phoneNumber,$profileLodge,$getImageHole)
	{
		
		$sql="update tbl_comment set fullname=:fullname,comment=:comment,date=:date,phone=:phone,lodge=:lodge,school=:school,domain_school=:domain_school,status=:bot where status=:value";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':value'=>$getImageHole,':fullname'=>$UserName,':comment'=>$commentByUser,':date'=>time(),':phone'=>$phoneNumber,':lodge'=>$profileLodge,':school'=>$school,':domain_school'=>$domain_school,':bot'=>""));
	}
	public function updateChatRecord($chat_id)
	{
		$sql="update tbl_chat set status=:status where chat_id=:chat_id";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':status'=>"old",':chat_id'=>$chat_id));
	}
	public function updateCommentRecordToOld($id)
	{
		$sql="update tbl_comment set status=:status where id=:id";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':status'=>"old",':id'=>$id));
	}
	public function updateUserPassword($member_id,$newPassword)
	{
		$sql="update tbl_member set password=:newPassword where id_member=:member_id and delete_status=:d_status";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':member_id'=>$member_id,':newPassword'=>$newPassword,':d_status'=>0));
		
		$this->output =array("success"=>1,"Msg"=>"Your Password had been changed successfully.");
		return json_encode($this->output);
	}
	public function updateStatus($newStatus,$myPhone)
	{
		$myPhone=$_SESSION['user_phone'];
		$sql="update tbl_user set status=:status where user_number=:user_number";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':status'=>$newStatus,':user_number'=>$myPhone));
	}
	
	
	public function changeName($name,$phone)
	{
		$sql="update tbl_user set user_full_name=:user_full_name where user_number=:user_number";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_full_name'=>$name,':user_number'=>$phone));
	}
	public function checkForUploadedPixM($pix,$phoneNumber)
	{
		$sql="update tbl_user set pix=:pix where user_number=:user_number";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':pix'=>$pix,':user_number'=>$phoneNumber));
		
		$sql="update tbl_pixoperation set status=:status where pix=:pix";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':pix'=>$pix,':status'=>"old"));
		
	}
	
	
	public function alarmSetting($op,$myPhone)
	{
	
			$myPhone=$_SESSION['user_phone'];
		
		
		//updateData::alarmOParetion($mydate,$myhour,$myPhone);
		
		$sql="update lecture_lecture_timetable set switch=:new  where user_phone=:user_phone";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_phone'=>$myPhone,':new'=>$op));
		
	}
	
	public function updateAlarm($myPhone,$mydate,$myhour)
	{
	
			$myPhone=$_SESSION['user_phone'];
		$new="N".$myhour;
		
		//updateData::alarmOParetion($mydate,$myhour,$myPhone);
		
		$sql="update lecture_lecture_timetable set FromT=:new  where user_phone=:user_phone and Day=:date and FromT=:hour";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_phone'=>$myPhone,':date'=>$mydate,':hour'=>$myhour,':new'=>$new));
		
	}
	
	
	public function alarmOParetion($mydate,$correct,$myPhone)
	{
			$myPhone=$_SESSION['user_phone'];
		
		//echo	$this->output= " dbjfdkb";
		//
		
		$new=str_replace("N","",$correct);
		$old=date('h')-1; 
		$neww=$new+1;
		if($old>$new){
		$sql="update lecture_lecture_timetable set FromT=:new  where user_phone=:user_phone and Day=:date and FromT=:hour";
		$query=$this->conn->prepare($sql);
		$query->execute(array(':user_phone'=>$myPhone,':date'=>$mydate,':hour'=>$correct,':new'=>$new));
		
		
	 
		  
		  
		
		
		
		
		}
		// else
		// {
		// }
	}
	
	public function updatePics($myPhone,$pimage){
			$myPhone=$_SESSION['user_phone'];
				$sql="update  tbl_user set picture=:pimage where user_number=:user_number";
				$query=$this->conn->prepare($sql);
				$query->execute(array(':user_number'=>$myPhone,':pimage'=>$pimage));
				
	}
		public function updateStatusLine($phone){
		
				$sql="update  tbl_user set lineStatus=:lineStatus where user_number=:user_number";
				$query=$this->conn->prepare($sql);
				$query->execute(array(':user_number'=>$phone,':lineStatus'=>"ONLINE"));
				
	}
	public function updateStatusLineN($phone,$status){
		
				$sql="update  tbl_user set lineStatus=:lineStatus where user_number=:user_number";
				$query=$this->conn->prepare($sql);
				$query->execute(array(':user_number'=>$phone,':lineStatus'=>$status));
				
	}
	public function followUserUpdate($FollowedNumber,$FollowerNumber,$count){
		
				$sql="update  tbl_follow set count=:count where beenFollowed=:FollowedNumber";
				$query=$this->conn->prepare($sql);
				$query->execute(array(':count'=>$count,':FollowedNumber'=>$FollowedNumber));
				
	}
	public function changePassword($phone,$newpass){
			$phone=$_SESSION['user_phone'];
				$sql="update  tbl_user set user_password=:newpass where user_number=:user_number";
				$query=$this->conn->prepare($sql);
				$query->execute(array(':newpass'=>$newpass,':user_number'=>$phone));
				
	}
}
?>